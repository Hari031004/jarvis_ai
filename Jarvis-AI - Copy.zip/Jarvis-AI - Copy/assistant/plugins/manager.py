﻿"""Dynamic plugin loading and command dispatch."""

from __future__ import annotations

import importlib.util
import json
import time
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Protocol

from assistant.config import Settings
from assistant.memory.database import SQLiteStore, utc_now
from assistant.security import PermissionManager
from assistant.utils.helpers import normalize_text
from assistant.utils.logger import get_logger


class PluginCommand(Protocol):
    def __call__(self, text: str) -> str:
        """Handle a plugin command."""


@dataclass(slots=True)
class Plugin:
    id: str
    name: str
    version: str
    description: str
    permissions: list[str]
    module: ModuleType
    path: Path
    mtime: float


class PluginManager:
    """Loads plugins from a configured directory with manifest-based permissions."""

    def __init__(
        self,
        settings: Settings,
        permissions: PermissionManager,
        store: SQLiteStore | None = None,
    ) -> None:
        self.settings = settings
        self.permissions = permissions
        self.store = store
        self.logger = get_logger(__name__)
        self.plugins: dict[str, Plugin] = {}
        self.commands: dict[str, PluginCommand] = {}
        self.plugins_dir = settings.plugins_dir.expanduser()
        self.plugins_dir.mkdir(parents=True, exist_ok=True)

    def load_all(self) -> None:
        if not self.settings.enable_plugins:
            self.logger.info("Plugin system disabled.")
            return
        for manifest in self.plugins_dir.glob("*/plugin.json"):
            self.load_plugin(manifest.parent)

    def reload_changed(self) -> None:
        if not self.settings.enable_plugin_hot_reload:
            return
        for manifest in self.plugins_dir.glob("*/plugin.json"):
            plugin_id = manifest.parent.name
            current = self.plugins.get(plugin_id)
            mtime = manifest.stat().st_mtime
            if current is None or mtime > current.mtime:
                self.load_plugin(manifest.parent)

    def load_plugin(self, folder: Path) -> None:
        decision = self.permissions.check("plugin", str(folder))
        if not decision.allowed:
            self.logger.warning("Plugin blocked: %s", decision.reason)
            return
        manifest_path = folder / "plugin.json"
        module_path = folder / "plugin.py"
        if not manifest_path.exists() or not module_path.exists():
            self.logger.warning("Skipping invalid plugin folder: %s", folder)
            return

        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        plugin_id = str(manifest.get("id") or folder.name)
        permissions = [str(item) for item in manifest.get("permissions", [])]
        for permission in permissions:
            decision = self.permissions.check(permission, str(folder))
            if not decision.allowed:
                self.logger.warning("Plugin %s permission denied: %s", plugin_id, decision.reason)
                return

        spec = importlib.util.spec_from_file_location(f"jarvis_plugin_{plugin_id}", module_path)
        if spec is None or spec.loader is None:
            self.logger.warning("Could not import plugin: %s", plugin_id)
            return
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        plugin = Plugin(
            id=plugin_id,
            name=str(manifest.get("name") or plugin_id),
            version=str(manifest.get("version") or "0.0.0"),
            description=str(manifest.get("description") or ""),
            permissions=permissions,
            module=module,
            path=folder,
            mtime=max(manifest_path.stat().st_mtime, module_path.stat().st_mtime, time.time()),
        )
        self.plugins[plugin_id] = plugin
        self._register_commands(plugin, manifest)
        if self.store:
            self.store.execute(
                """
                INSERT OR REPLACE INTO plugins
                    (id, name, version, enabled, permissions, path, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    plugin.id,
                    plugin.name,
                    plugin.version,
                    1,
                    json.dumps(plugin.permissions),
                    str(plugin.path),
                    utc_now(),
                ),
            )
        self.logger.info("Loaded plugin %s %s", plugin.name, plugin.version)

    def dispatch(self, text: str) -> str | None:
        self.reload_changed()
        normalized = normalize_text(text)
        for phrase, handler in self.commands.items():
            if normalized == phrase or normalized.startswith(phrase + " "):
                return handler(text)
        return None

    def _register_commands(self, plugin: Plugin, manifest: dict) -> None:
        commands = manifest.get("commands", [])
        for command in commands:
            phrase = normalize_text(str(command.get("phrase", "")))
            function_name = str(command.get("function", "handle"))
            handler = getattr(plugin.module, function_name, None)
            if phrase and callable(handler):
                self.commands[phrase] = handler

