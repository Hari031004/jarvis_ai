"""Extensible plugin and MCP integration."""

from assistant.plugins.manager import PluginManager
from assistant.plugins.mcp_client import MCPClient, MCPServerConfig

__all__ = ["MCPClient", "MCPServerConfig", "PluginManager"]
