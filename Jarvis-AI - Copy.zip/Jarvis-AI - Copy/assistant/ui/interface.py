"""UIInterface — the single contract between the event bus and any frontend.

Design rationale
────────────────
The interface intentionally exposes **one abstract method**:

    handle_event(event: AssistantEvent) -> None

This achieves complete UI independence:

  • The backend publishes typed AssistantEvent objects to the EventBus.
  • The JarvisBridge subscribes to the EventBus, enqueues events, and
    calls ``handle_event()`` on whichever adapter is connected.
  • Each adapter (PySide6, Tkinter, Web, CLI, …) translates the event
    into framework-specific calls internally.

The backend never knows — and never needs to know — whether the frontend
is a desktop window, a web socket, a REST endpoint, or nothing at all.
Swapping the entire UI requires only replacing the adapter, not touching
any backend code.

Lifecycle
─────────
Two optional lifecycle hooks let adapters initialise and tear down
cleanly without forcing every implementor to define them:

    start() → None   called once when the adapter is connected
    stop()  → None   called once when the assistant is shutting down

Both default to no-ops so simple adapters need not override them.

Minimal surface area is intentional
─────────────────────────────────────
Earlier designs proposed dozens of UI-specific methods
(``set_state()``, ``update_cpu()``, ``user_message()``, …).  That
approach couples the interface to one particular frontend layout.  The
single-method design puts all translation logic inside the adapter,
keeping the interface stable forever regardless of UI changes.

Usage
─────
    from assistant.ui.interface import UIInterface
    from assistant.core.events import AssistantEvent, EventType

    class MyAdapter(UIInterface):
        def handle_event(self, event: AssistantEvent) -> None:
            if event.type == EventType.USER_MESSAGE:
                self._show_user_bubble(event.payload.text)
            elif event.type == EventType.STATE_CHANGED:
                self._update_orb(event.payload.new_state)
            # … etc.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from assistant.core.events import AssistantEvent


class UIInterface(ABC):
    """Minimal contract that every JARVIS frontend adapter must satisfy.

    Implementors receive :class:`~assistant.core.events.AssistantEvent`
    objects and are free to dispatch them however suits their framework.

    Thread-safety note
    ──────────────────
    ``handle_event()`` will be called from the GUI thread (the bridge
    ensures this via its internal queue + QTimer drain cycle).
    Implementors do **not** need to make ``handle_event()`` thread-safe,
    but they must not block the call for significant time.
    """

    @abstractmethod
    def handle_event(self, event: AssistantEvent) -> None:
        """Translate a backend event into a UI update.

        This is the **only** method the bridge calls.  Implementations
        should dispatch on ``event.type`` and update the appropriate
        part of the UI.

        Args:
            event: A fully populated :class:`AssistantEvent` delivered
                   from the EventBus via the bridge.  The payload type
                   matches the event type (see ``assistant.core.events``
                   for the full payload catalogue).

        Raises:
            Should not raise.  Wrap internal logic in try/except and
            log errors rather than propagating them — a crashing UI
            update must not kill the bridge or the backend.
        """

    # ── Optional lifecycle hooks ──────────────────────────────────────────────

    def start(self) -> None:
        """Called once when the bridge connects this adapter.

        Override to initialise UI state, start background timers, or
        emit a welcome notification.  Default implementation is a no-op.
        """

    def stop(self) -> None:
        """Called once when the assistant is shutting down.

        Override to flush any pending updates, stop timers, or show a
        farewell animation.  Default implementation is a no-op.
        """

    # ── Introspection ─────────────────────────────────────────────────────────

    @property
    def adapter_name(self) -> str:
        """Human-readable name of this adapter (defaults to class name).

        Used for logging and diagnostics only.  Override to return a
        custom string, e.g. ``"PySide6 Desktop"`` or ``"WebSocket"``.
        """
        return type(self).__name__
