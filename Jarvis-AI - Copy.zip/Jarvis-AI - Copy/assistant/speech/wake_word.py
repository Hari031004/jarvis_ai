"""Offline wake-word detection powered by OpenWakeWord with auto-restart and multi-mic support."""

from __future__ import annotations

import queue
import time
from threading import Event

import numpy as np
import sounddevice as sd

from assistant.config import Settings
from assistant.utils.logger import get_logger
from assistant.core.event_bus import publish_event
from assistant.core.events import EventType, EventSource

OPENWAKEWORD_SAMPLE_RATE = 16000
OPENWAKEWORD_MODEL_NAME = "hey_jarvis"


class WakeWordDetector:
    """Continuously listens for the configured wake phrase with auto-restart and multi-mic support."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.logger = get_logger(__name__)
        self._model = None
        self._prediction_keys_printed = False
        self._model_load_attempted = False
        self._reconnect_attempts = 0
        self._max_reconnect_attempts = 10
        self._recent_scores: list[float] = []

    def wait_for_wake_word(self, stop_event: Event | None = None) -> bool:
        """Block until OpenWakeWord detects the wake phrase. Auto-restarts on failure."""

        if not self.settings.wake_word_enabled:
            self.logger.info("Wake word detection is disabled; continuing immediately.")
            return True

        while stop_event is None or not stop_event.is_set():
            try:
                result = self._attempt_wake_detection(stop_event)
                if result:
                    self._reconnect_attempts = 0
                    return True
            except sd.PortAudioError as exc:
                self._report_error(
                    "Microphone unavailable for wake word detection. Check INPUT_DEVICE and microphone permissions.",
                    exc,
                )
                self._reconnect_attempts += 1
            except Exception as exc:
                self._report_error("Wake word listener stopped unexpectedly.", exc)
                self._reconnect_attempts += 1

            if not self.settings.wake_word_auto_restart:
                return False

            if self._reconnect_attempts >= self._max_reconnect_attempts:
                self.logger.error(
                    "Max reconnect attempts (%d) reached. Giving up.",
                    self._max_reconnect_attempts,
                )
                return False

            delay = min(
                self.settings.wake_word_restart_delay_seconds * (2 ** min(self._reconnect_attempts, 5)),
                30.0,
            )
            self.logger.info(
                "Restarting wake word listener in %.1f seconds (attempt %d/%d)...",
                delay,
                self._reconnect_attempts,
                self._max_reconnect_attempts,
            )
            time.sleep(delay)

            if self.settings.wake_word_model_reload_on_failure:
                self._model = None
                self._model_load_attempted = False

        return False

    def _get_working_input_device(self) -> int | str | None:
        """Scan for a working input device if the configured one fails."""
        dev = self.settings.input_device
        try:
            sd.check_input_settings(device=dev, samplerate=OPENWAKEWORD_SAMPLE_RATE, channels=1)
            return dev
        except Exception:
            self.logger.warning("Configured input device %s is not working for wake word detection. Scanning for working microphones...", dev)
            try:
                devices = sd.query_devices()
                for idx, device in enumerate(devices):
                    if device["max_input_channels"] > 0:
                        try:
                            sd.check_input_settings(device=idx, samplerate=OPENWAKEWORD_SAMPLE_RATE, channels=1)
                            self.logger.info("Auto-selected working microphone: %s (index %d)", device["name"], idx)
                            return idx
                        except Exception:
                            continue
            except Exception as exc:
                self.logger.error("Failed to query sound devices: %s", exc)
        return None

    def _attempt_wake_detection(self, stop_event: Event | None = None) -> bool:
        """Single attempt at wake word detection."""

        try:
            model = self._get_model()
        except Exception as exc:
            self._report_error(
                "Wake word detection could not start. Install OpenWakeWord and download the models.",
                exc,
            )
            return False

        model.reset()
        audio_queue: queue.Queue[np.ndarray] = queue.Queue(maxsize=4)
        block_size = 1280  # 80ms at 16kHz — lower CPU than 2560

        def callback(indata, frames, time_info, status) -> None:  # type: ignore[no-untyped-def]
            if status:
                self.logger.debug("Wake word stream status: %s", status)
            try:
                audio_queue.put_nowait(indata.copy().reshape(-1))
            except queue.Full:
                pass  # silently drop — no need to log every drop

        self.logger.info("Sleeping. Waiting for wake word: %s", self.settings.wake_word)
        device = self._get_working_input_device()
        try:
            with sd.InputStream(
                samplerate=OPENWAKEWORD_SAMPLE_RATE,
                channels=1,
                dtype="int16",
                blocksize=block_size,
                device=device,
                callback=callback,
            ):
                self.logger.debug("Wake word microphone opened at %s Hz.", OPENWAKEWORD_SAMPLE_RATE)
                while stop_event is None or not stop_event.is_set():
                    try:
                        chunk = audio_queue.get(timeout=0.5)
                    except queue.Empty:
                        continue

                    predictions = model.predict(chunk)
                    self._print_prediction_keys_once(predictions)
                    score = self._wake_score(predictions)
                    
                    self.logger.debug("Wake word detection predictions: %s, raw score: %.4f (threshold: %.4f)",
                                      predictions, score, self.settings.wakeword_threshold)

                    if score >= self.settings.wakeword_threshold:
                        self.logger.info("Wake word detected with score %.4f.", score)
                        # Publish WAKE_DETECTED event
                        publish_event(EventType.WAKE_DETECTED, source=EventSource.WAKE_WORD)
                        return True
        except sd.PortAudioError:
            raise
        except Exception as exc:
            self.logger.error("Wake word stream error: %s", exc)
            return False

        return False

    def list_microphones(self) -> list[dict]:
        """List all available microphones for selection."""
        devices = []
        try:
            for i, device in enumerate(sd.query_devices()):
                if device["max_input_channels"] > 0:
                    devices.append({
                        "index": i,
                        "name": device["name"],
                        "channels": device["max_input_channels"],
                        "sample_rate": device["default_samplerate"],
                    })
        except Exception as exc:
            self.logger.error("Failed to list microphones: %s", exc)
        return devices

    def select_microphone(self, device_name: str) -> int | None:
        """Select a microphone by name substring match."""
        devices = self.list_microphones()
        for device in devices:
            if device_name.lower() in device["name"].lower():
                self.logger.info("Selected microphone: %s (index %d)", device["name"], device["index"])
                return device["index"]
        self.logger.warning("No microphone found matching '%s'", device_name)
        return None

    def _get_model(self):  # type: ignore[no-untyped-def]
        if self._model is None and not self._model_load_attempted:
            self._model_load_attempted = True
            try:
                from openwakeword.model import Model
                from openwakeword import utils as openwakeword_utils
            except ImportError as exc:
                raise RuntimeError("OpenWakeWord is not installed. Run: pip install openwakeword") from exc

            try:
                openwakeword_utils.download_models([OPENWAKEWORD_MODEL_NAME])
            except Exception as exc:
                self.logger.debug("OpenWakeWord model download check failed: %s", exc)

            self._model = Model(wakeword_models=["hey_jarvis"], inference_framework="onnx")
            self.logger.debug(
                "OpenWakeWord model loaded: %s using ONNX.",
                OPENWAKEWORD_MODEL_NAME,
            )
        return self._model

    def reload_model(self) -> None:
        """Force reload the wake word model."""
        self._model = None
        self._model_load_attempted = False
        self.logger.info("Wake word model will be reloaded on next detection attempt.")

    def _wake_score(self, predictions: dict[str, float]) -> float:
        scores = [
            float(score)
            for prediction_name, score in predictions.items()
            if "jarvis" in prediction_name.lower()
        ]
        return max(scores, default=0.0)

    def _print_prediction_keys_once(self, predictions: dict[str, float]) -> None:
        if self._prediction_keys_printed:
            return
        prediction_keys = list(predictions.keys())
        print(f"OpenWakeWord prediction keys: {prediction_keys}")
        self._prediction_keys_printed = True

    def _report_error(self, message: str, exc: Exception) -> None:
        self.logger.error("%s %s", message, exc)
        print(f"{message}\nDetails: {exc}")