"""Audio preprocessing, VAD, wake-word text matching, and voice profile utilities."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from assistant.config import Settings
from assistant.utils.helpers import normalize_text
from assistant.utils.logger import get_logger


class AudioPreprocessor:
    """Applies lightweight normalization and noise suppression."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.noise_floor = 0.004
        self._noise_profile = np.zeros(128, dtype=np.float32)
        self._noise_profile_frames = 0
        self._max_profile_frames = 50

    def process(self, audio: np.ndarray) -> np.ndarray:
        if audio.size == 0:
            return audio.astype(np.float32)
        data = audio.reshape(-1).astype(np.float32)
        if self.settings.enable_noise_suppression:
            data = self.reduce_noise(data)
        peak = float(np.max(np.abs(data))) if data.size else 0.0
        if peak > 0:
            data = data / max(1.0, peak)
        return np.clip(data, -1.0, 1.0)

    def reduce_noise(self, audio: np.ndarray) -> np.ndarray:
        if audio.size < 16:
            return audio
        floor = float(np.percentile(np.abs(audio), 20))
        self.noise_floor = 0.92 * self.noise_floor + 0.08 * floor
        gate = max(self.noise_floor * self.settings.noise_gate_multiplier, 0.001)
        filtered = np.where(np.abs(audio) < gate, audio * 0.18, audio)
        return filtered.astype(np.float32)

    def reduce_noise_adaptive(self, audio: np.ndarray) -> np.ndarray:
        """Adaptive noise reduction using spectral subtraction (low CPU)."""
        if audio.size < 256:
            return audio

        # Build noise profile from first frames (assumed silence)
        if self._noise_profile_frames < self._max_profile_frames:
            frame = audio[: min(audio.size, 256)]
            if frame.size >= 128:
                spectrum = np.abs(np.fft.rfft(frame[:128]))
                alpha = 1.0 / (self._noise_profile_frames + 1)
                self._noise_profile = (1.0 - alpha) * self._noise_profile + alpha * spectrum.astype(np.float32)
                self._noise_profile_frames += 1

        if self._noise_profile_frames < 5:
            return audio  # not enough profile yet

        # Apply spectral subtraction in chunks
        chunk_size = 256
        result = np.empty_like(audio)
        for start in range(0, audio.size, chunk_size):
            chunk = audio[start : start + chunk_size]
            if chunk.size < 32:
                result[start : start + chunk.size] = chunk
                continue
            spectrum = np.fft.rfft(chunk)
            magnitude = np.abs(spectrum)
            phase = np.angle(spectrum)
            # Subtract noise profile (interpolated to match chunk size)
            noise = np.interp(
                np.linspace(0, 1, magnitude.size),
                np.linspace(0, 1, self._noise_profile.size),
                self._noise_profile,
            )
            cleaned = np.maximum(magnitude - noise * 1.2, 0.0)
            result[start : start + chunk.size] = np.fft.irfft(cleaned * np.exp(1j * phase), n=chunk.size)
        return result.astype(np.float32)

    def is_keyboard_noise(self, audio: np.ndarray) -> bool:
        """Detect keyboard click noise by analyzing high-frequency transients."""
        if audio.size < 64:
            return False
        # Keyboard clicks have sharp transients — high zero-crossing rate + wide spectrum
        zcr = float(np.mean(np.abs(np.diff(np.signbit(audio).astype(np.int8)))))
        if zcr < 0.3:
            return False
        # Check for high-frequency energy spike
        spectrum = np.abs(np.fft.rfft(audio[: min(audio.size, 256)]))
        if spectrum.size < 4:
            return False
        high_freq = float(np.mean(spectrum[spectrum.size // 2 :]))
        low_freq = float(np.mean(spectrum[: spectrum.size // 4])) + 1e-9
        ratio = high_freq / low_freq
        # Keyboard clicks have high high-frequency ratio and short duration
        return ratio > 3.0 and audio.size < 512

    def is_fan_noise(self, audio: np.ndarray) -> bool:
        """Detect steady fan/background noise by checking spectral flatness."""
        if audio.size < 128:
            return False
        spectrum = np.abs(np.fft.rfft(audio[: min(audio.size, 256)]))
        if spectrum.size < 4 or float(np.sum(spectrum)) < 1e-9:
            return False
        # Spectral flatness: geometric mean / arithmetic mean
        log_spectrum = np.log(spectrum + 1e-9)
        geometric = float(np.exp(np.mean(log_spectrum)))
        arithmetic = float(np.mean(spectrum))
        flatness = geometric / (arithmetic + 1e-9)
        # Fan noise is spectrally flat (white/pink noise-like)
        return flatness > 0.6

    def cancel_echo(self, microphone: np.ndarray, reference: np.ndarray | None = None) -> np.ndarray:
        if reference is None or reference.size == 0 or microphone.size == 0:
            return microphone
        length = min(microphone.size, reference.size)
        mic = microphone[:length].astype(np.float32)
        ref = reference[:length].astype(np.float32)
        scale = float(np.dot(mic, ref) / (np.dot(ref, ref) + 1e-9))
        cleaned = mic - scale * ref * self.settings.echo_cancellation_strength
        if microphone.size > length:
            cleaned = np.concatenate([cleaned, microphone[length:]])
        return cleaned.astype(np.float32)


class VoiceActivityDetector:
    """Energy-based VAD with adaptive noise tracking, keyboard/fan rejection, and optional WebRTC VAD."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.noise_floor = settings.speech_stop_threshold
        self._webrtc_vad = None
        self._webrtc_initialized = False
        self._preprocessor = AudioPreprocessor(settings)
        self._speech_history: list[bool] = []
        self._history_max = 10
        self._consecutive_silence = 0
        self._consecutive_speech = 0
        if settings.vad_use_webrtc:
            self._init_webrtc_vad()

    def _init_webrtc_vad(self) -> None:
        """Initialize WebRTC VAD if available."""
        try:
            import webrtcvad  # type: ignore[import-untyped]

            self._webrtc_vad = webrtcvad.Vad(self.settings.vad_mode)
            self._webrtc_initialized = True
        except ImportError:
            self._webrtc_initialized = False

    def is_speech(self, chunk: np.ndarray) -> bool:
        """Detect speech using energy-based VAD with noise rejection and hysteresis."""
        if chunk.size < 16:
            return False

        # Reject keyboard noise
        if self._preprocessor.is_keyboard_noise(chunk):
            return False

        # Reject fan/steady noise
        if self._preprocessor.is_fan_noise(chunk):
            return False

        rms_val = self.rms(chunk)
        self.noise_floor = min(max(0.9 * self.noise_floor + 0.1 * rms_val, 0.001), 0.08)
        threshold = max(self.settings.speech_stop_threshold, self.noise_floor * 2.4)
        energy_speech = rms_val >= threshold

        if self._webrtc_initialized and self._webrtc_vad is not None:
            try:
                webrtc_speech = self._check_webrtc_vad(chunk)
                combined = energy_speech or webrtc_speech
            except Exception:
                combined = energy_speech
        else:
            combined = energy_speech

        # Hysteresis: require multiple consecutive frames to switch state
        self._speech_history.append(combined)
        if len(self._speech_history) > self._history_max:
            self._speech_history.pop(0)

        if combined:
            self._consecutive_speech += 1
            self._consecutive_silence = 0
        else:
            self._consecutive_silence += 1
            self._consecutive_speech = 0

        # Require 2 consecutive speech frames to declare speech (reduces false triggers)
        if self._consecutive_speech >= 2:
            return True
        # Require 3 consecutive silence frames to declare silence (avoids chopping)
        if self._consecutive_silence >= 3:
            return False
        # During transition, use majority vote of recent history
        if len(self._speech_history) >= 3:
            return sum(self._speech_history) > len(self._speech_history) // 2
        return combined

    def _check_webrtc_vad(self, chunk: np.ndarray) -> bool:
        """Check WebRTC VAD for a chunk of audio."""
        if self._webrtc_vad is None:
            return False
        int16_data = np.clip(chunk * 32767, -32768, 32767).astype(np.int16)
        pcm_bytes = int16_data.tobytes()
        frame_duration_ms = int(len(pcm_bytes) / 2 / 16)  # 16 samples per ms at 16kHz
        if frame_duration_ms in (10, 20, 30):
            return self._webrtc_vad.is_speech(pcm_bytes, self.settings.sample_rate)
        return False

    def is_silence(self, chunk: np.ndarray) -> bool:
        """Return True if the chunk is silence."""
        return not self.is_speech(chunk)

    def detect_voice_activity(self, audio: np.ndarray, sample_rate: int) -> list[tuple[int, int]]:
        """Detect voice activity regions in audio. Returns list of (start_sample, end_sample) tuples."""
        frame_size = int(sample_rate * 0.03)  # 30ms frames
        if frame_size < 1:
            return []

        regions: list[tuple[int, int]] = []
        in_speech = False
        speech_start = 0
        min_speech_frames = max(1, self.settings.vad_min_speech_duration_ms // 30)
        min_silence_frames = max(1, self.settings.vad_min_silence_duration_ms // 30)
        silence_frames = 0
        speech_frames = 0

        for start in range(0, len(audio), frame_size):
            frame = audio[start : start + frame_size]
            if len(frame) < frame_size // 2:
                break

            is_speech = self.is_speech(frame)
            if is_speech:
                speech_frames += 1
                silence_frames = 0
                if not in_speech and speech_frames >= min_speech_frames:
                    in_speech = True
                    speech_start = max(0, start - min_speech_frames * frame_size)
            else:
                silence_frames += 1
                if in_speech and silence_frames >= min_silence_frames:
                    in_speech = False
                    regions.append((speech_start, start))
                    speech_frames = 0

        if in_speech:
            regions.append((speech_start, len(audio)))

        return regions

    @staticmethod
    def rms(chunk: np.ndarray) -> float:
        if chunk.size == 0:
            return 0.0
        return float(np.sqrt(np.mean(np.square(chunk.astype(np.float32)))))


class WakeWordMatcher:
    """Matches configured wake words in transcribed text."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.wake_words = [normalize_text(word) for word in settings.wake_words if word.strip()]

    def matches(self, text: str) -> bool:
        normalized = normalize_text(text)
        return any(word and word in normalized for word in self.wake_words)


@dataclass(slots=True)
class VoiceProfile:
    name: str
    embedding: list[float]
    samples: int = 1


class VoiceProfileStore:
    """Stores simple speaker embeddings for identification and authentication."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.path = settings.voice_profiles_file.expanduser()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.logger = get_logger(__name__)
        self._profiles = self._load()

    def enroll(self, name: str, audio: np.ndarray) -> VoiceProfile:
        embedding = extract_voice_embedding(audio, self.settings.sample_rate)
        existing = self._profiles.get(name)
        if existing:
            merged = _average(existing.embedding, embedding, existing.samples)
            profile = VoiceProfile(name=name, embedding=merged, samples=existing.samples + 1)
        else:
            profile = VoiceProfile(name=name, embedding=embedding, samples=1)
        self._profiles[name] = profile
        self._save()
        return profile

    def identify(self, audio: np.ndarray) -> tuple[str | None, float]:
        if not self._profiles:
            return None, 0.0
        embedding = extract_voice_embedding(audio, self.settings.sample_rate)
        best_name: str | None = None
        best_score = -1.0
        for name, profile in self._profiles.items():
            score = cosine_similarity(embedding, profile.embedding)
            if score > best_score:
                best_name = name
                best_score = score
        if best_score < self.settings.voice_auth_threshold:
            return None, best_score
        return best_name, best_score

    def authenticate(self, expected_name: str, audio: np.ndarray) -> bool:
        name, score = self.identify(audio)
        self.logger.info("Voice auth expected=%s actual=%s score=%.3f", expected_name, name, score)
        return name == expected_name and score >= self.settings.voice_auth_threshold

    def _load(self) -> dict[str, VoiceProfile]:
        if not self.path.exists():
            return {}
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            return {
                item["name"]: VoiceProfile(
                    name=item["name"],
                    embedding=[float(v) for v in item["embedding"]],
                    samples=int(item.get("samples", 1)),
                )
                for item in raw
            }
        except Exception as exc:
            self.logger.warning("Failed to load voice profiles: %s", exc)
            return {}

    def _save(self) -> None:
        payload = [
            {"name": profile.name, "embedding": profile.embedding, "samples": profile.samples}
            for profile in self._profiles.values()
        ]
        self.path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def extract_voice_embedding(audio: np.ndarray, sample_rate: int) -> list[float]:
    data = audio.reshape(-1).astype(np.float32)
    if data.size == 0:
        return [0.0] * 12
    data = data - float(np.mean(data))
    rms = float(np.sqrt(np.mean(np.square(data))))
    zcr = float(np.mean(np.abs(np.diff(np.signbit(data).astype(np.int8)))))
    spectrum = np.abs(np.fft.rfft(data[: min(data.size, sample_rate * 3)]))
    if spectrum.size == 0 or float(np.sum(spectrum)) == 0.0:
        centroid = 0.0
        rolloff = 0.0
        bands = [0.0] * 8
    else:
        freqs = np.fft.rfftfreq((spectrum.size - 1) * 2, d=1 / sample_rate)
        total = float(np.sum(spectrum))
        centroid = float(np.sum(freqs * spectrum) / total) / (sample_rate / 2)
        cumulative = np.cumsum(spectrum)
        rolloff_index = int(np.searchsorted(cumulative, total * 0.85))
        rolloff = float(freqs[min(rolloff_index, freqs.size - 1)]) / (sample_rate / 2)
        bands = []
        for split in np.array_split(spectrum, 8):
            bands.append(float(np.mean(split)) / (float(np.max(spectrum)) + 1e-9))
    return _normalize([rms, zcr, centroid, rolloff, *bands])


def cosine_similarity(a: list[float], b: list[float]) -> float:
    left = np.array(a, dtype=np.float32)
    right = np.array(b, dtype=np.float32)
    denom = float(np.linalg.norm(left) * np.linalg.norm(right))
    if denom == 0:
        return 0.0
    return float(np.dot(left, right) / denom)


def _normalize(values: list[float]) -> list[float]:
    norm = math.sqrt(sum(value * value for value in values))
    if norm == 0:
        return values
    return [float(value / norm) for value in values]


def _average(old: list[float], new: list[float], old_count: int) -> list[float]:
    count = max(1, old_count)
    merged = [(old_value * count + new_value) / (count + 1) for old_value, new_value in zip(old, new)]
    return _normalize(merged)