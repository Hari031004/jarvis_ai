"""Minimal Model Context Protocol client for external stdio servers."""

from __future__ import annotations

import json
import subprocess
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from assistant.config import Settings
from assistant.utils.logger import get_logger


@dataclass(slots=True)
class MCPServerConfig:
    name: str
    command: list[str]
    cwd: Path | None = None
    env: dict[str, str] = field(default_factory=dict)


class MCPClient:
    """JSON-RPC client for MCP stdio servers."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.logger = get_logger(__name__)
        self._processes: dict[str, subprocess.Popen[str]] = {}
        self._lock = threading.RLock()
        self._next_id = 1

    def start(self, server: MCPServerConfig) -> None:
        if not self.settings.enable_mcp:
            self.logger.info("MCP disabled; not starting %s", server.name)
            return
        with self._lock:
            if server.name in self._processes:
                return
            process = subprocess.Popen(
                server.command,
                cwd=str(server.cwd) if server.cwd else None,
                env=server.env or None,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
            )
            self._processes[server.name] = process
            self.request(server.name, "initialize", {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "jarvis", "version": "1.0.0"}})

    def stop_all(self) -> None:
        with self._lock:
            for process in self._processes.values():
                process.terminate()
            self._processes.clear()

    def list_tools(self, server_name: str) -> list[dict[str, Any]]:
        response = self.request(server_name, "tools/list", {})
        return response.get("tools", [])

    def call_tool(self, server_name: str, tool_name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        return self.request(server_name, "tools/call", {"name": tool_name, "arguments": arguments})

    def request(self, server_name: str, method: str, params: dict[str, Any]) -> dict[str, Any]:
        process = self._processes.get(server_name)
        if process is None or process.stdin is None or process.stdout is None:
            raise RuntimeError(f"MCP server is not running: {server_name}")
        request_id = self._next_request_id()
        payload = {"jsonrpc": "2.0", "id": request_id, "method": method, "params": params}
        process.stdin.write(json.dumps(payload) + "\n")
        process.stdin.flush()
        while True:
            line = process.stdout.readline()
            if not line:
                raise RuntimeError(f"MCP server closed stdout: {server_name}")
            message = json.loads(line)
            if message.get("id") != request_id:
                continue
            if "error" in message:
                raise RuntimeError(str(message["error"]))
            return message.get("result", {})

    def _next_request_id(self) -> int:
        with self._lock:
            request_id = self._next_id
            self._next_id += 1
            return request_id
