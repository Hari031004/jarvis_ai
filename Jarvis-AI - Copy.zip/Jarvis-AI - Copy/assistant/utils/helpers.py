"""Shared utility functions."""

from __future__ import annotations

import os
import re
import subprocess
import webbrowser
from datetime import datetime, timedelta
from pathlib import Path
from typing import Iterable


STOP_PHRASES = {
    "stop listening",
    "sleep",
    "go to sleep",
    "goodbye",
    "good bye",
    "exit",
    "cancel",
}


def normalize_text(text: str) -> str:
    """Normalize spoken text for command matching."""

    lowered = text.lower().strip()
    lowered = re.sub(r"[^a-z0-9\s:/\\._-]", " ", lowered)
    return re.sub(r"\s+", " ", lowered).strip()


def contains_stop_phrase(text: str) -> bool:
    normalized = normalize_text(text)
    return any(phrase == normalized or phrase in normalized for phrase in STOP_PHRASES)


def strip_command_prefix(text: str, prefixes: Iterable[str]) -> str:
    normalized = normalize_text(text)
    for prefix in sorted(prefixes, key=len, reverse=True):
        if normalized == prefix:
            return ""
        if normalized.startswith(prefix + " "):
            return normalized[len(prefix) + 1 :].strip()
    return ""


def strip_name_words(text: str) -> str:
    return re.sub(r"^(called|named|name|as|to)\s+", "", text.strip(), flags=re.IGNORECASE)


def clean_filename(name: str, default: str) -> str:
    cleaned = strip_name_words(name)
    cleaned = cleaned.strip().strip("\"'")
    cleaned = re.sub(r"[<>:\"|?*]", "-", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned or default


def resolve_user_path(raw: str, base_dir: Path) -> Path:
    """Resolve a spoken path or file name into a filesystem path."""

    cleaned = clean_filename(raw, "untitled").replace(" slash ", "/").replace(" backslash ", "\\")
    expanded = os.path.expandvars(os.path.expanduser(cleaned))
    candidate = Path(expanded)
    if candidate.is_absolute():
        return candidate
    return base_dir / candidate


def open_path(path: Path) -> None:
    """Open a local path in the OS shell."""
    from assistant.utils.logger import get_logger
    logger = get_logger("assistant.utils.helpers")
    logger.info("Browser navigation: assistant/utils/helpers.py:open_path request_id: N/A destination URL: %s", path.resolve().as_uri())
    if os.name == "nt":
        os.startfile(str(path))  # type: ignore[attr-defined]
        return
    webbrowser.open(path.resolve().as_uri())


def run_process(args: list[str], timeout: float = 12.0) -> subprocess.CompletedProcess[str]:
    """Run a subprocess and capture useful output."""

    return subprocess.run(
        args,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )


def parse_duration(text: str) -> timedelta | None:
    """Parse durations like '5 minutes' or '1 hour 30 minutes'."""

    normalized = normalize_text(text)
    unit_seconds = {
        "second": 1,
        "seconds": 1,
        "sec": 1,
        "secs": 1,
        "minute": 60,
        "minutes": 60,
        "min": 60,
        "mins": 60,
        "hour": 3600,
        "hours": 3600,
        "day": 86400,
        "days": 86400,
    }
    total = 0.0
    for amount, unit in re.findall(r"(\d+(?:\.\d+)?)\s*(seconds?|secs?|minutes?|mins?|hours?|days?)", normalized):
        total += float(amount) * unit_seconds[unit]
    if total <= 0:
        return None
    return timedelta(seconds=total)


def parse_alarm_time(text: str, now: datetime | None = None) -> datetime | None:
    """Parse a simple time of day from speech."""

    now = now or datetime.now()
    normalized = normalize_text(text)
    match = re.search(r"\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\b", normalized)
    if not match:
        return None

    hour = int(match.group(1))
    minute = int(match.group(2) or 0)
    meridiem = match.group(3)

    if meridiem == "pm" and hour < 12:
        hour += 12
    if meridiem == "am" and hour == 12:
        hour = 0
    if hour > 23 or minute > 59:
        return None

    scheduled = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if scheduled <= now:
        scheduled += timedelta(days=1)
    return scheduled


def human_timedelta(delta: timedelta) -> str:
    total = int(delta.total_seconds())
    if total < 60:
        return f"{total} seconds"
    minutes, seconds = divmod(total, 60)
    if minutes < 60:
        return f"{minutes} minutes" if seconds == 0 else f"{minutes} minutes and {seconds} seconds"
    hours, minutes = divmod(minutes, 60)
    if hours < 24:
        return f"{hours} hours" if minutes == 0 else f"{hours} hours and {minutes} minutes"
    days, hours = divmod(hours, 24)
    return f"{days} days" if hours == 0 else f"{days} days and {hours} hours"


def sentence_join(items: list[str], limit: int = 5) -> str:
    selected = items[:limit]
    if not selected:
        return ""
    if len(selected) == 1:
        return selected[0]
    return ", ".join(selected[:-1]) + f", and {selected[-1]}"


def truncate_for_speech(text: str, max_chars: int = 700) -> str:
    normalized = re.sub(r"\s+", " ", text).strip()
    if len(normalized) <= max_chars:
        return normalized
    return normalized[: max_chars - 3].rstrip() + "..."
