"""Microphone listener for active voice sessions with adaptive VAD and auto-reconnect."""

from __future__ import annotations

import queue
import time
from collections.abc import Iterator

import numpy as np
import sounddevice as sd

from assistant.speech.audio_processing import AudioPreprocessor, VoiceActivityDetector
from assistant.config import Settings
from assistant.utils.logger import get_logger


class WakeListener:
    """Records utterances after the assistant wakes with VAD, noise filtering, and auto-reconnect."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.logger = get_logger(__name__)
        self.preprocessor = AudioPreprocessor(settings)
        self.vad = VoiceActivityDetector(settings)

    def record_utterance(self) -> np.ndarray:
        """Record one spoken utterance, ending after a silence window. Retries on failure."""

        max_retries = 3
        for attempt in range(max_retries):
            try:
                frames: list[np.ndarray] = []
                for chunk in self.record_chunks():
                    frames.append(chunk)
                if not frames:
                    return np.array([], dtype=np.float32)
                audio = np.concatenate(frames, axis=0).reshape(-1).astype(np.float32)
                return self.preprocessor.process(audio)
            except sd.PortAudioError as exc:
                self.logger.warning(
                    "Microphone error (attempt %d/%d): %s",
                    attempt + 1, max_retries, exc,
                )
                if attempt < max_retries - 1:
                    time.sleep(0.5)
                else:
                    self.logger.error("Microphone unavailable after %d attempts.", max_retries)
                    return np.array([], dtype=np.float32)
            except Exception as exc:
                self.logger.exception("Recording error: %s", exc)
                return np.array([], dtype=np.float32)
        return np.array([], dtype=np.float32)

    def _get_working_input_device(self) -> int | str | None:
        """Scan for a working input device if the configured one fails."""
        dev = self.settings.input_device
        try:
            sd.check_input_settings(device=dev, samplerate=self.settings.sample_rate, channels=1)
            return dev
        except Exception:
            self.logger.warning("Configured input device %s is not working. Scanning for working microphones...", dev)
            try:
                devices = sd.query_devices()
                for idx, device in enumerate(devices):
                    if device["max_input_channels"] > 0:
                        try:
                            sd.check_input_settings(device=idx, samplerate=self.settings.sample_rate, channels=1)
                            self.logger.info("Auto-selected working microphone: %s (index %d)", device["name"], idx)
                            return idx
                        except Exception:
                            continue
            except Exception as exc:
                self.logger.error("Failed to query sound devices: %s", exc)
        return None

    def record_chunks(self) -> Iterator[np.ndarray]:
        """Yield audio chunks for one utterance using adaptive voice activity detection."""

        audio_queue: queue.Queue[np.ndarray] = queue.Queue(maxsize=32)
        block_size = max(512, int(self.settings.sample_rate * 0.06))

        def callback(indata, frames, time_info, status) -> None:  # type: ignore[no-untyped-def]
            if status:
                self.logger.debug("Speech stream status: %s", status)
            try:
                audio_queue.put_nowait(indata.copy())
            except queue.Full:
                self.logger.debug("Dropping microphone chunk because the queue is full.")

        started = False
        speech_started_at = 0.0
        last_voice_at = 0.0
        pre_roll: list[np.ndarray] = []
        max_pre_roll = 5

        self.logger.info("Listening for speech.")
        device = self._get_working_input_device()
        try:
            with sd.InputStream(
                samplerate=self.settings.sample_rate,
                channels=1,
                dtype="float32",
                blocksize=block_size,
                device=device,
                callback=callback,
            ):
                while True:
                    chunk = audio_queue.get()
                    chunk = self.preprocessor.reduce_noise(chunk.reshape(-1))
                    now = time.monotonic()
                    amplitude = self.vad.rms(chunk)
                    speech = self.vad.is_speech(chunk) or amplitude >= self.settings.speech_start_threshold

                    # Detailed debug logging for speech recognition activity
                    self.logger.debug("Recording VAD check: amplitude=%.6f, threshold=%.6f, raw_speech=%s", 
                                      amplitude, self.settings.speech_start_threshold, speech)

                    if speech and self.settings.tts_interrupt_enabled:
                        from assistant.speech.text_to_speech import TextToSpeech
                        if getattr(TextToSpeech, "active_instance", None):
                            tts = TextToSpeech.active_instance
                            if tts.is_speaking:
                                # Require amplitude to exceed 3.0x threshold to override acoustic feedback loopback
                                if amplitude >= self.settings.speech_start_threshold * 3.0:
                                    self.logger.info("User speech detected above loopback threshold (amplitude=%.6f). Interrupting TTS.", amplitude)
                                    tts.interrupt()
                                else:
                                    self.logger.debug("Speech signal (amplitude=%.6f) ignored to prevent self-interruption loopback.", amplitude)
                                    speech = False

                    if not started:
                        pre_roll.append(chunk)
                        pre_roll = pre_roll[-max_pre_roll:]
                        if speech:
                            started = True
                            speech_started_at = now
                            last_voice_at = now
                            for item in pre_roll:
                                yield item
                        continue

                    yield chunk
                    if speech or amplitude >= self.settings.speech_stop_threshold:
                        last_voice_at = now

                    elapsed = now - speech_started_at
                    silence = now - last_voice_at
                    min_elapsed = elapsed >= self.settings.speech_min_seconds
                    if min_elapsed and silence >= self.settings.speech_silence_seconds:
                        break
                    if elapsed >= self.settings.speech_max_seconds:
                        self.logger.info("Speech recording reached maximum duration.")
                        break
        except sd.PortAudioError as exc:
            self.logger.error("Microphone stream error: %s", exc)
            raise