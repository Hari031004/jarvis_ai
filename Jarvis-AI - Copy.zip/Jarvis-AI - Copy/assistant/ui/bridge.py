"""JarvisBridge and EventDispatcher — the event delivery layer.

Architecture position
─────────────────────
    Backend  →  EventBus  →  JarvisBridge  →  EventDispatcher  →  UIInterface

This module contains **two abstractions**, both free of any UI framework:

  EventDispatcher (ABC)
      Receives AssistantEvent objects from JarvisBridge (called from any
      thread) and delivers them to a UIInterface on the correct thread.
      The *how* of thread switching is left to concrete implementations —
      PySideDispatcher (in pyside_adapter.py) uses a queue + QTimer;
      a hypothetical WebSocketDispatcher might use asyncio; a test stub
      might call handle_event() directly.

  JarvisBridge
      Subscribes to the process-wide EventBus and forwards every
      AssistantEvent to the attached EventDispatcher.  It is the only
      component that holds a reference to the EventBus.

Design constraints
──────────────────
  • Zero UI-framework dependencies (no PySide6, no Tkinter).
  • Zero backend dependencies (no brain, no config, no psutil).
  • All Qt classes live exclusively in pyside_adapter.py.
  • JarvisBridge is safe to call from any thread.
  • EventDispatcher.dispatch() is safe to call from any thread.
  • Only one dispatcher may be attached at a time.

Lifecycle
─────────

    # At application start:
    bridge = get_bridge()
    bridge.attach(PySideDispatcher(adapter))   # inject dispatcher
    bridge.start()                              # subscribe to EventBus

    # At shutdown:
    bridge.stop()      # unsubscribe from EventBus, stop dispatcher
    bridge.detach()    # release the dispatcher reference

Singleton
─────────
    get_bridge() → JarvisBridge   (process-wide, lazily created)
"""

from __future__ import annotations

import logging
import threading
from abc import ABC, abstractmethod

from assistant.core.event_bus import get_event_bus
from assistant.core.events import AssistantEvent
from assistant.ui.interface import UIInterface

logger = logging.getLogger(__name__)


# ════════════════════════════════════════════════════════════════════════════
# EventDispatcher — abstract delivery mechanism
# ════════════════════════════════════════════════════════════════════════════


class EventDispatcher(ABC):
    """Abstract base for delivering AssistantEvents to a UIInterface.

    Responsibility split
    ─────────────────────
      JarvisBridge  — knows *what* events exist and who produces them.
      EventDispatcher — knows *how* to deliver events to the adapter on
                        the correct thread for the target UI framework.

    Thread contract
    ───────────────
    ``dispatch()`` is always called from a background thread (the thread
    that published the event to the EventBus).  Concrete implementations
    must not call ``adapter.handle_event()`` directly from ``dispatch()``
    unless they are certain the adapter is thread-safe — Qt widgets are
    not.  Instead, buffer the event and deliver it from the GUI thread
    (e.g. via a queue + QTimer in PySideDispatcher).

    Lifecycle
    ─────────
    ``start()`` is called once after the dispatcher is attached to the
    bridge.  ``stop()`` is called once at shutdown.  Both default to
    no-ops so minimal test dispatchers need not override them.
    """

    @abstractmethod
    def dispatch(self, event: AssistantEvent) -> None:
        """Accept *event* from any thread and arrange delivery to the adapter.

        This method must return immediately — do not block the calling
        (backend) thread.  Buffer the event and deliver asynchronously.

        Args:
            event: The event to deliver.
        """

    def start(self) -> None:
        """Initialise the dispatcher (e.g. start a drain timer).

        Called once by JarvisBridge after :meth:`attach`.
        Default is a no-op.
        """

    def stop(self) -> None:
        """Tear down the dispatcher (e.g. stop a drain timer).

        Called once by JarvisBridge during :meth:`~JarvisBridge.stop`.
        Default is a no-op.
        """

    @property
    def is_running(self) -> bool:
        """Whether the dispatcher is currently active.

        Concrete implementations should override this to reflect their
        internal state (e.g. whether the QTimer is active).
        """
        return False

    @property
    def adapter_name(self) -> str:
        """Descriptive name for logging (defaults to class name)."""
        return type(self).__name__


# ════════════════════════════════════════════════════════════════════════════
# JarvisBridge
# ════════════════════════════════════════════════════════════════════════════


class JarvisBridge:
    """Subscribes to the EventBus and forwards events to an EventDispatcher.

    JarvisBridge is UI-framework agnostic — it knows nothing about Qt,
    Tkinter, or any other frontend technology.  All framework-specific
    logic lives inside the injected EventDispatcher.

    Public API
    ──────────
        attach(dispatcher)   Inject the delivery mechanism.
        detach()             Remove the delivery mechanism.
        start()              Subscribe to EventBus; start dispatcher.
        stop()               Unsubscribe from EventBus; stop dispatcher.
        is_running → bool
        has_dispatcher → bool

    Example::

        bridge = get_bridge()
        dispatcher = PySideDispatcher(PySideAdapter(window))
        bridge.attach(dispatcher)
        bridge.start()
        # … application runs …
        bridge.stop()
        bridge.detach()
    """

    def __init__(self) -> None:
        self._lock: threading.Lock = threading.Lock()
        self._dispatcher: EventDispatcher | None = None
        self._running: bool = False
        self._bus = get_event_bus()

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def attach(self, dispatcher: EventDispatcher) -> None:
        """Inject the :class:`EventDispatcher` that will deliver events.

        If a dispatcher is already attached it is silently replaced.
        Attach before calling :meth:`start` so no events are lost.

        Args:
            dispatcher: A concrete :class:`EventDispatcher` instance.
        """
        with self._lock:
            self._dispatcher = dispatcher
        logger.info(
            "JarvisBridge: dispatcher attached (%s)", dispatcher.adapter_name
        )

    def detach(self) -> None:
        """Remove the attached dispatcher.

        After detaching, events published to the EventBus are silently
        dropped.  Call :meth:`stop` before ``detach()`` to ensure the
        dispatcher is cleanly shut down first.
        """
        with self._lock:
            name = self._dispatcher.adapter_name if self._dispatcher else "none"
            self._dispatcher = None
        logger.info("JarvisBridge: dispatcher detached (was %s)", name)

    def start(self) -> None:
        """Subscribe to the EventBus and start the dispatcher.

        Idempotent — calling ``start()`` on an already-running bridge
        is a no-op and does not register duplicate subscriptions.
        """
        with self._lock:
            if self._running:
                logger.debug("JarvisBridge.start() called but already running.")
                return
            self._running = True
            dispatcher = self._dispatcher

        # subscribe_all ensures we never miss an event regardless of type.
        self._bus.subscribe_all(self._on_event)

        if dispatcher is not None:
            dispatcher.start()
            logger.info(
                "JarvisBridge started — dispatcher: %s", dispatcher.adapter_name
            )
        else:
            logger.warning(
                "JarvisBridge started with no dispatcher attached. "
                "Events will be dropped until attach() is called."
            )

    def stop(self) -> None:
        """Unsubscribe from the EventBus and stop the dispatcher.

        Idempotent — safe to call multiple times.
        """
        with self._lock:
            if not self._running:
                return
            self._running = False
            dispatcher = self._dispatcher

        self._bus.unsubscribe_all(self._on_event)

        if dispatcher is not None:
            dispatcher.stop()

        logger.info("JarvisBridge stopped.")

    # ── Internal EventBus handler ─────────────────────────────────────────────

    def _on_event(self, event: AssistantEvent) -> None:
        """Called by the EventBus from whatever thread published the event.

        This method must return as fast as possible — it runs on the
        publishing thread (often the voice/LLM pipeline).  All it does
        is grab the dispatcher reference and hand off the event.
        """
        with self._lock:
            dispatcher = self._dispatcher

        if dispatcher is not None:
            try:
                dispatcher.dispatch(event)
            except Exception:
                logger.exception(
                    "JarvisBridge: dispatcher.dispatch() raised for event %r",
                    event.type,
                )

    # ── Introspection ─────────────────────────────────────────────────────────

    @property
    def is_running(self) -> bool:
        """Whether the bridge is subscribed to the EventBus."""
        with self._lock:
            return self._running

    @property
    def has_dispatcher(self) -> bool:
        """Whether a dispatcher is currently attached."""
        with self._lock:
            return self._dispatcher is not None


# ════════════════════════════════════════════════════════════════════════════
# Process-wide singleton
# ════════════════════════════════════════════════════════════════════════════

_bridge: JarvisBridge | None = None
_bridge_lock: threading.Lock = threading.Lock()


def get_bridge() -> JarvisBridge:
    """Return the process-wide :class:`JarvisBridge` singleton.

    Thread-safe via double-checked locking.  The singleton is created
    lazily on first access.

    Returns:
        The single shared :class:`JarvisBridge` instance for this process.
    """
    global _bridge
    if _bridge is None:
        with _bridge_lock:
            if _bridge is None:
                _bridge = JarvisBridge()
    return _bridge
