"""UI abstraction layer: interface, bridge, and adapters.

The backend never imports from this package directly.
Communication happens exclusively through the EventBus.
"""
