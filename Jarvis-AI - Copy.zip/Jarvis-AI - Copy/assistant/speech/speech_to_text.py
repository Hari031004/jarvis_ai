"""Speech-to-text using Faster Whisper with streaming, partial transcription, and multi-language support."""

from __future__ import annotations

import tempfile
import time
import wave
from collections.abc import Iterable, Iterator
from pathlib import Path

import numpy as np
from faster_whisper import WhisperModel

from assistant.speech.audio_processing import AudioPreprocessor
from assistant.config import Settings
from assistant.utils.logger import get_logger
from assistant.core.event_bus import publish_event
from assistant.core.events import EventType, EventSource


class SpeechToText:
    """Lazy-loaded Faster Whisper transcriber with model caching, streaming, and multi-language support."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.logger = get_logger(__name__)
        self.preprocessor = AudioPreprocessor(settings)
        self._model: WhisperModel | None = None
        self._model_loaded = False
        self._max_retries = 2

        # Concurrency & Hot-Reload state
        import threading
        self._aliases_lock = threading.Lock()
        self._aliases_cache: dict[str, str] = {}
        self._aliases_mtime: float = 0.0
        self._pattern_index: dict[str, list] = {}
        self._sorted_patterns: list[str] = []
        self._pattern_word_starts: dict[str, list[str]] = {}
        self._pattern_boundaries: dict[str, tuple[str, str]] = {}
        self._ensure_aliases_file_exists()

    def _ensure_aliases_file_exists(self) -> None:
        path = getattr(self.settings, "stt_aliases_file", None)
        if path:
            try:
                from pathlib import Path
                import json
                path = Path(path)
                if not path.exists():
                    path.parent.mkdir(parents=True, exist_ok=True)
                    template = {
                        "universities": {},
                        "cities": {},
                        "people": {},
                        "applications": {},
                        "brands": {},
                        "custom": {}
                    }
                    with open(path, "w", encoding="utf-8") as f:
                        json.dump(template, f, indent=2)
                    self.logger.info("Created default STT aliases template at: %s", path)
            except Exception as e:
                self.logger.warning("Could not initialize STT aliases template: %s", e)

    def warmup(self) -> None:
        """Load the model before the first user utterance to reduce perceived latency."""
        if self.settings.stt_provider == "nvidia" and self.settings.nvidia_api_key:
            self.logger.info("STT Provider: NVIDIA Whisper Large v3 (Skipping Faster Whisper preload)")
            return
        self._get_model()

    def transcribe(self, audio: np.ndarray) -> str:
        """Transcribe audio to text with language auto-detection support."""
        if audio.size == 0:
            return ""

        # Publish STT_START event
        corr = publish_event(EventType.STT_START, source=EventSource.STT)

        processed = self.preprocessor.process(audio)
        path = self._write_temp_wav(processed)
        try:
            use_fallback = True
            if self.settings.stt_provider == "nvidia":
                self.logger.info("STT Provider: NVIDIA Whisper Large v3")
                if not self.settings.nvidia_api_key:
                    self.logger.info("NVIDIA unavailable, switching to Faster Whisper")
                else:
                    try:
                        self.logger.info("Using NVIDIA transcription")
                        import requests
                        url = "https://grpc.nvcf.nvidia.com/v1/audio/transcriptions"
                        headers = {
                            "Authorization": f"Bearer {self.settings.nvidia_api_key}",
                            "function-id": "1598d209-5e27-4d3c-8079-4751568b1081",
                        }
                        with open(path, "rb") as audio_file:
                            files = {
                                "file": (path.name, audio_file, "audio/wav")
                            }
                            data = {
                                "language": self._nvidia_language(self.settings.whisper_language or "en-US")
                            }
                            response = requests.post(
                                url,
                                headers=headers,
                                files=files,
                                data=data,
                                timeout=self.settings.http_timeout_seconds,
                            )
                        response.raise_for_status()
                        text = response.json().get("text", "").strip()
                        self.logger.info("NVIDIA transcription successful")
                        self.logger.info("Transcribed: %s", text)
                        return self.normalize_proper_nouns(text)
                    except Exception as exc:
                        self.logger.warning("NVIDIA transcription failed: %s", exc)
                        self.logger.info("NVIDIA unavailable, switching to Faster Whisper")

            model = self._get_model()
            language = None if self.settings.whisper_auto_detect_language else self.settings.whisper_language

            for attempt in range(self._max_retries):
                try:
                    segments, info = model.transcribe(
                        str(path),
                        beam_size=1,
                        vad_filter=True,
                        language=language,
                        condition_on_previous_text=False,
                    )
                    text = " ".join(segment.text.strip() for segment in segments).strip()

                    if info and info.language:
                        self.logger.info(
                            "Detected language: %s (probability: %.2f)",
                            info.language,
                            info.language_probability,
                        )

                    self.logger.info("Transcribed: %s", text)
                    return self.normalize_proper_nouns(text)
                except Exception as exc:
                    if attempt < self._max_retries - 1:
                        self.logger.warning("Transcription attempt %d failed: %s. Retrying...", attempt + 1, exc)
                        time.sleep(0.2)
                    else:
                        self.logger.error("Transcription failed after %d attempts: %s", self._max_retries, exc)
                        return ""
        finally:
            path.unlink(missing_ok=True)
            publish_event(
                EventType.STT_END,
                source=EventSource.STT,
                correlation_id=corr.correlation_id
            )

    def transcribe_stream(
        self,
        chunks: Iterable[np.ndarray],
        min_seconds: float = 0.8,
    ) -> Iterator[str]:
        """Yield increasingly complete transcripts from a stream of audio chunks."""

        buffered: list[np.ndarray] = []
        buffered_seconds = 0.0
        for chunk in chunks:
            buffered.append(chunk)
            buffered_seconds += chunk.size / float(self.settings.sample_rate)
            if buffered_seconds >= min_seconds:
                text = self.transcribe(np.concatenate(buffered).reshape(-1))
                if text:
                    yield text
                buffered_seconds = 0.0
        if buffered:
            text = self.transcribe(np.concatenate(buffered).reshape(-1))
            if text:
                yield text

    def transcribe_partial(
        self,
        chunks: Iterable[np.ndarray],
        partial_interval: float | None = None,
    ) -> Iterator[str]:
        """Yield partial transcriptions at regular intervals for real-time feedback."""

        interval = partial_interval or self.settings.whisper_partial_interval_seconds
        buffered: list[np.ndarray] = []
        last_yield = time.monotonic()

        for chunk in chunks:
            buffered.append(chunk)
            now = time.monotonic()
            if now - last_yield >= interval:
                audio = np.concatenate(buffered).reshape(-1)
                text = self.transcribe(audio)
                if text:
                    yield text
                last_yield = now

        if buffered:
            audio = np.concatenate(buffered).reshape(-1)
            text = self.transcribe(audio)
            if text:
                yield text

    def transcribe_with_language(self, audio: np.ndarray, language: str | None = None) -> str:
        """Transcribe with explicit language override."""
        if audio.size == 0:
            return ""

        processed = self.preprocessor.process(audio)
        path = self._write_temp_wav(processed)
        try:
            use_fallback = True
            if self.settings.stt_provider == "nvidia":
                self.logger.info("STT Provider: NVIDIA Whisper Large v3")
                if not self.settings.nvidia_api_key:
                    self.logger.info("NVIDIA unavailable, switching to Faster Whisper")
                else:
                    try:
                        self.logger.info("Using NVIDIA transcription")
                        import requests
                        url = "https://grpc.nvcf.nvidia.com/v1/audio/transcriptions"
                        headers = {
                            "Authorization": f"Bearer {self.settings.nvidia_api_key}",
                            "function-id": "1598d209-5e27-4d3c-8079-4751568b1081",
                        }
                        with open(path, "rb") as audio_file:
                            files = {
                                "file": (path.name, audio_file, "audio/wav")
                            }
                            data = {
                                "language": self._nvidia_language(language or "en-US")
                            }
                            response = requests.post(
                                url,
                                headers=headers,
                                files=files,
                                data=data,
                                timeout=self.settings.http_timeout_seconds,
                            )
                        response.raise_for_status()
                        text = response.json().get("text", "").strip()
                        self.logger.info("NVIDIA transcription successful")
                        self.logger.info("Transcribed: %s", text)
                        return self.normalize_proper_nouns(text)
                    except Exception as exc:
                        self.logger.warning("NVIDIA transcription failed: %s", exc)
                        self.logger.info("NVIDIA unavailable, switching to Faster Whisper")

            if use_fallback:
                self.logger.info("Using Faster Whisper")
                model = self._get_model()
                for attempt in range(self._max_retries):
                    try:
                        segments, _ = model.transcribe(
                            str(path),
                            beam_size=1,
                            vad_filter=True,
                            language=language,
                            condition_on_previous_text=False,
                        )
                        text = " ".join(segment.text.strip() for segment in segments).strip()
                        self.logger.info("Transcribed (lang=%s): %s", language or "auto", text)
                        return self.normalize_proper_nouns(text)
                    except Exception as exc:
                        if attempt < self._max_retries - 1:
                            time.sleep(0.2)
                        else:
                            self.logger.error("Transcription failed: %s", exc)
                            return ""
        finally:
            path.unlink(missing_ok=True)

    def _get_model(self) -> WhisperModel:
        if self._model is None and not self._model_loaded:
            self._model_loaded = True
            self.logger.info("Loading Faster Whisper model...")
            self.logger.info(
                "Loading Faster Whisper model: %s (%s, %s)",
                self.settings.whisper_model_size,
                self.settings.whisper_device,
                self.settings.whisper_compute_type,
            )
            self._model = WhisperModel(
                self.settings.whisper_model_size,
                device=self.settings.whisper_device,
                compute_type=self.settings.whisper_compute_type,
            )
        return self._model

    def reload_model(self, model_size: str | None = None) -> None:
        """Force reload the Whisper model, optionally with a different size."""
        self._model = None
        self._model_loaded = False
        if model_size:
            self.settings.whisper_model_size = model_size
        self.logger.info("Whisper model will be reloaded on next transcription.")

    def _write_temp_wav(self, audio: np.ndarray) -> Path:
        clipped = np.clip(audio, -1.0, 1.0)
        pcm = (clipped * 32767).astype(np.int16)
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as file:
            path = Path(file.name)
        with wave.open(str(path), "wb") as wav_file:
            wav_file.setnchannels(1)
            wav_file.setsampwidth(2)
            wav_file.setframerate(self.settings.sample_rate)
            wav_file.writeframes(pcm.tobytes())
        return path

    @staticmethod
    def _nvidia_language(lang: str) -> str:
        """Normalize bare ISO-639 language codes to BCP-47 locale format expected by NVIDIA.

        The NVIDIA grpc.nvcf endpoint rejects bare codes like 'en'; it requires 'en-US'.
        """
        _map = {
            "en": "en-US",
            "fr": "fr-FR",
            "de": "de-DE",
            "es": "es-ES",
            "it": "it-IT",
            "pt": "pt-BR",
            "zh": "zh-CN",
            "ja": "ja-JP",
            "ko": "ko-KR",
            "ru": "ru-RU",
            "ar": "ar-AE",
            "hi": "hi-IN",
        }
        if "-" in lang or "_" in lang:
            return lang  # already a locale code
        return _map.get(lang.lower(), lang + "-" + lang.upper())

    def load_aliases(self) -> tuple[dict[str, str], str, str]:
        """Thread-safe load and hot-reload aliases with partial-write and permission error recovery.

        Returns:
            tuple: (flat_aliases_dict, reload_source_str, cache_status_str)
        """
        path = getattr(self.settings, "stt_aliases_file", None)
        if not path:
            return {}, "None", "Inactive"

        from pathlib import Path
        path = Path(path)
        
        try:
            if not path.exists():
                return {}, "None", "Inactive"
            current_mtime = path.stat().st_mtime
        except Exception as e:
            return self._aliases_cache, "Cache", f"Error: {type(e).__name__}"

        reload_source = "Cache"
        cache_status = "Hit"

        with self._aliases_lock:
            # Hot reload check
            if current_mtime != self._aliases_mtime:
                import json
                import unicodedata
                
                try:
                    # Prevent reading empty or partially written file
                    if path.stat().st_size == 0:
                        raise ValueError("File is empty (possible concurrent write)")

                    with open(path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        
                    # Validate top-level is a dict
                    if not isinstance(data, dict):
                        raise ValueError("Root element must be a JSON object")

                    flat_aliases = {}
                    for category, val in data.items():
                        if isinstance(val, dict):
                            for k, v in val.items():
                                if isinstance(k, str) and isinstance(v, str):
                                    clean_k = unicodedata.normalize("NFC", k.lower().replace("-", " ").strip())
                                    flat_aliases[clean_k] = unicodedata.normalize("NFC", v)
                        elif isinstance(val, str):
                            clean_k = unicodedata.normalize("NFC", category.lower().replace("-", " ").strip())
                            flat_aliases[clean_k] = unicodedata.normalize("NFC", val)
                            
                    self._aliases_cache = flat_aliases
                    self._aliases_mtime = current_mtime
                    
                    # Sort and build first-char index
                    sorted_patterns = sorted(flat_aliases.keys(), key=lambda x: (len(x.split()), len(x)), reverse=True)
                    self._sorted_patterns = sorted_patterns
                    self._pattern_word_starts = {pattern: [pw[0] for pw in pattern.split() if pw] for pattern in flat_aliases}
                    self._pattern_boundaries = {
                        pattern: (p_words[0], p_words[-1]) if p_words else ("", "")
                        for pattern, p_words in ((p, p.split()) for p in flat_aliases)
                    }
                    from collections import defaultdict
                    index_map = defaultdict(list)
                    for pattern in sorted_patterns:
                        p_words = pattern.split()
                        if p_words:
                            # Index under the first character of every word in the pattern
                            first_chars = {pw[0].lower() for pw in p_words if pw}
                            for char in first_chars:
                                if pattern not in index_map[char]:
                                    index_map[char].append(pattern)
                    self._pattern_index = dict(index_map)
                    
                    reload_source = "File"
                    cache_status = "Reloaded"
                    self.logger.info("STT aliases hot-reloaded successfully from %s", path)
                except Exception as e:
                    self.logger.warning("Could not hot-reload STT aliases (%s). Using existing cache.", e)
            return self._aliases_cache, reload_source, cache_status

    def normalize_proper_nouns(self, text: str) -> str:
        """High-performance index-driven proper noun normalizer with structured diagnostics."""
        if not text:
            return text

        import difflib
        import unicodedata

        # Unicode normalization
        text = unicodedata.normalize("NFC", text)

        # Fast thread-safe check/reload
        aliases, reload_source, cache_status = self.load_aliases()
        if not aliases:
            return text

        # Replace hyphens with spaces for clean parsing
        text_normalized = text.replace("-", " ")
        words = text_normalized.split()
        
        # Punctuation cleaning helper
        def clean_word(w: str) -> str:
            return "".join(c for c in w if not unicodedata.category(c).startswith("P")).lower()

        clean_words = [clean_word(w) for w in words if w]
        input_first_chars = {cw[0] for cw in clean_words if cw}

        # Keep track of replacements for structured logging
        replacements_used = []

        with self._aliases_lock:
            word_starts = dict(self._pattern_word_starts)
            boundaries = dict(self._pattern_boundaries)

        # Collect unique candidates based on input word first characters to shrink candidate list
        candidate_set = set()
        for char in input_first_chars:
            with self._aliases_lock:
                if char in self._pattern_index:
                    candidate_set.update(self._pattern_index[char])
        
        # Sort candidates by length of words descending to match longer first
        candidates = sorted(candidate_set, key=lambda x: len(word_starts.get(x, [])), reverse=True)

        for pattern in candidates:
            replacement = aliases[pattern]
            pattern_chars = word_starts.get(pattern, [])
            pattern_len = len(pattern_chars)

            # Check windows of size pattern_len - 1 to pattern_len + 1 in decreasing order
            match_found = False
            for win_size in range(pattern_len + 1, max(1, pattern_len - 1) - 1, -1):
                if win_size > len(words) or match_found:
                    continue

                for i in range(len(words) - win_size + 1):
                    subphrase_words = words[i : i + win_size]
                    
                    # Prevent eating surrounding unrelated words:
                    # If window is larger than pattern, make sure the boundary words match the pattern boundaries
                    if win_size > pattern_len:
                        pattern_first, pattern_last = boundaries.get(pattern, ("", ""))
                        first_word_sim = difflib.SequenceMatcher(None, clean_word(subphrase_words[0]), pattern_first).ratio()
                        last_word_sim = difflib.SequenceMatcher(None, clean_word(subphrase_words[-1]), pattern_last).ratio()
                        if first_word_sim < 0.6 or last_word_sim < 0.6:
                            continue

                    subphrase = " ".join([clean_word(w) for w in subphrase_words])
                    
                    # Compute similarity ratio
                    ratio = difflib.SequenceMatcher(None, subphrase, pattern).ratio()
                    if ratio >= 0.8:  # Confidence threshold for matching phonetic/fuzzy variants
                        target_phrase = " ".join(subphrase_words)
                        words[i : i + win_size] = [replacement]
                        
                        replacements_used.append({
                            "pattern": pattern,
                            "replacement": replacement,
                            "target": target_phrase,
                            "confidence": ratio
                        })
                        
                        # Re-update words list to reflect the changes
                        clean_words = [clean_word(w) for w in words if w]
                        input_first_chars = {cw[0] for cw in clean_words if cw}
                        match_found = True
                        break

        result = " ".join(words)
        
        if replacements_used:
            for rep in replacements_used:
                self.logger.info(
                    "\nOriginal Transcript:\n%s\n\nNormalized Transcript:\n%s\n\nAlias Applied:\n%s -> %s\n\nConfidence:\n%.2f%%\n\nReload Source:\n%s\n\nCache Status:\n%s",
                    text,
                    result,
                    rep["pattern"],
                    rep["replacement"],
                    rep["confidence"] * 100,
                    reload_source,
                    cache_status
                )
        return result