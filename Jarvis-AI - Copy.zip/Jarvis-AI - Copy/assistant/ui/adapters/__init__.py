"""PySide6 UI adapter and dispatcher for JARVIS."""
