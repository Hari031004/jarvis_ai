"""Optional vision, OCR, and screen analysis."""

from assistant.vision.service import VisionResult, VisionService

__all__ = ["VisionResult", "VisionService"]
