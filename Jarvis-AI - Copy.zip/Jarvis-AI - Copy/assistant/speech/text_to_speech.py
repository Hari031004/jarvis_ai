"""Interruptible text-to-speech output using Microsoft Edge TTS with voice, speed, pitch, volume, and queue support."""

from __future__ import annotations

import math
import queue
import threading
import wave
import asyncio
import inspect
from collections.abc import Iterable
from io import BytesIO
from pathlib import Path
from threading import Event, RLock
from typing import Any

import numpy as np
import sounddevice as sd

from assistant.config import Settings
from assistant.utils.logger import get_logger
from assistant.core.event_bus import publish_event
from assistant.core.events import EventType, EventSource


class TextToSpeech:
    """Speaks assistant responses, supports interruption, voice tuning, queuing, and streaming."""

    active_instance: TextToSpeech | None = None

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.logger = get_logger(__name__)
        self._stop_event = Event()
        self._lock = RLock()
        self._speech_queue: queue.Queue[str] = queue.Queue()
        self._queue_thread: threading.Thread | None = None
        self._queue_running = False
        self._current_audio: Any = None
        self._is_speaking = False
        TextToSpeech.active_instance = self

        if settings.tts_queue_enabled:
            self._start_queue_worker()

    @property
    def is_speaking(self) -> bool:
        """Check if TTS is currently playing audio."""
        return self._is_speaking

    def interrupt(self) -> None:
        """Interrupt current speech immediately (called when user starts talking)."""
        self.logger.info("Playback interrupted")
        self.logger.debug("TTS interrupt called. Stopping playback and clearing queue.")
        was_speaking = self._is_speaking
        self._stop_event.set()
        self._clear_queue()
        try:
            sd.stop()
        except Exception as exc:
            self.logger.debug("Error stopping sounddevice: %s", exc)
        self._is_speaking = False
        
        # Publish voice interruption and end of TTS playback
        publish_event(EventType.VOICE_INTERRUPTED, source=EventSource.TTS)
        if was_speaking:
            publish_event(EventType.TTS_END, source=EventSource.TTS)

    def stop(self) -> None:
        """Interrupt active playback."""
        self.interrupt()

    def speak(self, text: str) -> None:
        """Speak text immediately or queue it."""
        self.logger.debug("TTS speak called with text: %r", text)
        if not text.strip():
            return

        with self._lock:
            if self._stop_event.is_set():
                self.logger.info("Playback resumed")
                self.logger.info("playback interruption recovery")
                self._stop_event.clear()

        if self.settings.tts_queue_enabled:
            self.logger.info("TTS queued")
            self._speech_queue.put(text)
        else:
            with self._lock:
                self._stop_event.clear()
                try:
                    self._speak_with_edge_tts(text)
                except Exception as exc:
                    self.logger.exception("Text-to-speech failed: %s", exc)
                    self._speak_with_sapi(text)

    def speak_stream(self, chunks: Iterable[str]) -> str:
        """Speak streamed LLM text sentence by sentence and return the full response."""

        buffer = ""
        full_response: list[str] = []
        for chunk in chunks:
            if self._stop_event.is_set():
                break
            full_response.append(chunk)
            buffer += chunk
            if self._is_sentence_boundary(buffer):
                self.speak(buffer.strip())
                buffer = ""
        if buffer.strip() and not self._stop_event.is_set():
            self.speak(buffer.strip())
        return "".join(full_response).strip()

    def speak_interruptible(self, text: str) -> None:
        """Speak text that can be interrupted by the next utterance."""
        self.interrupt()
        self.speak(text)

    def play_startup_sound(self) -> None:
        if self.settings.startup_sound_path and self.settings.startup_sound_path.exists():
            self._play_wav_file(self.settings.startup_sound_path)
            return
        self._play_generated_chime()

    def list_voices(self) -> list[dict[str, str]]:
        """List available Microsoft Edge TTS voices."""
        try:
            import edge_tts

            voices = edge_tts.list_voices()
            if inspect.isawaitable(voices):
                voices = self._run_async(voices)
            return [
                {
                    "name": v.get("ShortName", v.get("Name", "unknown")),
                    "locale": v.get("Locale", ""),
                    "gender": v.get("Gender", ""),
                }
                for v in voices
            ]
        except Exception as exc:
            self.logger.error("Failed to list Edge TTS voices: %s", exc)
            return []

    @staticmethod
    def _run_async(awaitable: Any) -> Any:
        """Resolve Edge TTS's async API from sync callers safely."""
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(awaitable)

        result: dict[str, Any] = {}
        error: dict[str, BaseException] = {}

        def runner() -> None:
            try:
                result["value"] = asyncio.run(awaitable)
            except BaseException as exc:
                error["exception"] = exc

        worker = threading.Thread(target=runner, daemon=True)
        worker.start()
        worker.join()
        if "exception" in error:
            raise error["exception"]
        return result["value"]

    def set_voice(self, voice_name: str) -> None:
        """Change the TTS voice."""
        self.settings.voice_name = voice_name
        self.logger.info("TTS voice set to: %s", voice_name)

    def _speak_with_edge_tts(self, text: str) -> None:
        import edge_tts

        rate_str = f"+{int((self.settings.tts_speed - 1.0) * 100)}%" if self.settings.tts_speed >= 1.0 else f"{int((self.settings.tts_speed - 1.0) * 100)}%"
        pitch_str = f"+{int((self.settings.tts_pitch - 1.0) * 100)}Hz" if self.settings.tts_pitch >= 1.0 else f"{int((self.settings.tts_pitch - 1.0) * 100)}Hz"
        volume_str = f"+{int((self.settings.tts_volume - 1.0) * 100)}%" if self.settings.tts_volume >= 1.0 else f"{int((self.settings.tts_volume - 1.0) * 100)}%"

        communicate = edge_tts.Communicate(
            text,
            voice=self.settings.voice_name,
            rate=rate_str,
            pitch=pitch_str,
            volume=volume_str,
        )
        audio = bytearray()
        for chunk in communicate.stream_sync():
            if self._stop_event.is_set():
                return
            if chunk.get("type") == "audio":
                audio.extend(chunk.get("data", b""))

        if not audio:
            raise RuntimeError("Microsoft Edge TTS returned no audio.")
        self.logger.info("Audio generated")
        self._play_encoded_audio(bytes(audio))

    def _play_encoded_audio(self, content: bytes) -> None:
        if self._stop_event.is_set() or not content:
            return

        import soundfile as sf

        audio, sample_rate = sf.read(BytesIO(content), dtype="float32", always_2d=True)
        self._play_float_audio(audio, sample_rate)

    @staticmethod
    def _is_sentence_boundary(text: str) -> bool:
        stripped = text.rstrip()
        return len(stripped) > 80 and stripped[-1:] in {".", "?", "!", "\n"}

    def _speak_with_sapi(self, text: str) -> None:
        if not text.strip() or self._stop_event.is_set():
            return
        try:
            import win32com.client

            speaker = win32com.client.Dispatch("SAPI.SpVoice")
            speaker.Rate = int((self.settings.tts_speed - 1.0) * 10)
            speaker.Volume = int(self.settings.tts_volume * 100)
            self.logger.info("Audio generated")
            speaker.Speak(text)
        except Exception:
            self.logger.info("Audio generated")
            self.logger.info("Assistant says: %s", text)

    def _play_generated_chime(self) -> None:
        sample_rate = 44100
        duration = 0.55
        t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
        envelope = np.exp(-4.5 * t)
        tone_a = np.sin(2 * math.pi * 587.33 * t)
        tone_b = np.sin(2 * math.pi * 880.00 * t)
        audio = (0.28 * tone_a + 0.18 * tone_b) * envelope
        self._play_float_audio(audio.astype(np.float32), sample_rate)

    def _play_wav_file(self, path: Path) -> None:
        with wave.open(str(path), "rb") as wav_file:
            channels = wav_file.getnchannels()
            sample_width = wav_file.getsampwidth()
            sample_rate = wav_file.getframerate()
            frames = wav_file.readframes(wav_file.getnframes())

        if sample_width != 2:
            raise ValueError("Startup WAV files must be 16-bit PCM.")
        audio = np.frombuffer(frames, dtype=np.int16).astype(np.float32) / 32768.0
        if channels > 1:
            audio = audio.reshape(-1, channels)
        self._play_float_audio(audio, sample_rate)

    def _play_float_audio(self, audio: np.ndarray, sample_rate: int) -> None:
        if self._stop_event.is_set():
            self.logger.debug("TTS playback cancelled before start (stop event is set).")
            return
        self._is_speaking = True
        self.logger.info("Playback started")
        
        # Publish TTS_START event
        publish_event(EventType.TTS_START, source=EventSource.TTS)
        
        self.logger.debug("Starting TTS audio playback: sample_rate=%d, device=%s", sample_rate, self.settings.output_device)
        try:
            sd.play(audio, samplerate=sample_rate, device=self.settings.output_device)
            sd.wait()
            self.logger.info("Playback finished")
            self.logger.debug("TTS audio playback completed successfully.")
        except Exception as exc:
            self.logger.error("Audio playback failed: %s", exc)
        finally:
            self._is_speaking = False
            # Publish TTS_END event
            publish_event(EventType.TTS_END, source=EventSource.TTS)


    def _start_queue_worker(self) -> None:
        """Start background thread to process the speech queue."""
        if self._queue_running:
            return
        self._queue_running = True
        self.logger.info("Worker started")

        def worker() -> None:
            while self._queue_running:
                try:
                    self.logger.debug("Worker alive")
                    text = self._speech_queue.get(timeout=0.5)
                    if text and not self._stop_event.is_set():
                        with self._lock:
                            self._stop_event.clear()
                            try:
                                self._speak_with_edge_tts(text)
                            except Exception as exc:
                                self.logger.exception("Queued TTS failed: %s", exc)
                                self._speak_with_sapi(text)
                except queue.Empty:
                    continue
                except Exception:
                    break

        self._queue_thread = threading.Thread(target=worker, name="tts-queue", daemon=True)
        self._queue_thread.start()

    def _clear_queue(self) -> None:
        """Clear all pending speech from the queue."""
        while not self._speech_queue.empty():
            try:
                self._speech_queue.get_nowait()
            except queue.Empty:
                break

    def stop_queue(self) -> None:
        """Stop the queue worker thread."""
        self._queue_running = False
        self._clear_queue()
