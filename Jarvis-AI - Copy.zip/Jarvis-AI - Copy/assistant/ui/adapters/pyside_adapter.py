"""PySide6-specific event dispatcher and UI adapter.

THIS IS THE ONLY MODULE IN THE ENTIRE JARVIS STACK THAT IMPORTS PySide6.

Two classes with strict separation of responsibility:

  PySideDispatcher  — knows about threads and queues, nothing about widgets.
                      Moves AssistantEvent objects from any background thread
                      onto the Qt GUI thread via queue + QTimer drain.

  PySideAdapter     — knows about widget APIs, nothing about threading.
                      Translates AssistantEvent objects into public widget
                      method calls using a dispatch table (EventType → handler).
                      All widget access goes through defensive property
                      accessors that return None if the window is not yet
                      connected, so startup ordering does not matter.

Architecture position:
    JarvisBridge
        │
        ▼  dispatcher.dispatch(event)   ← any thread, non-blocking
    PySideDispatcher
        │
        ▼  adapter.handle_event(event)  ← GUI thread only (QTimer drain)
    PySideAdapter
        │
        ▼  widget.public_method(…)      ← PySide6 widget API
    JarvisWindow / ChatPanel / VoiceVisualizer / …

Usage (from run_with_ui.py):

    app    = QApplication(sys.argv)
    window = JarvisWindow()

    adapter    = PySideAdapter()
    adapter.connect_window(window)          # inject window after creation

    dispatcher = PySideDispatcher(adapter)  # wrap adapter

    bridge = get_bridge()
    bridge.attach(dispatcher)               # inject dispatcher
    bridge.start()                          # subscribe to EventBus

    window.show()
    app.exec()

    bridge.stop()
    bridge.detach()
"""

from __future__ import annotations

import datetime
import logging
import queue
from typing import Any, Callable

from abc import ABCMeta

from PySide6.QtCore import QObject, QTimer

from assistant.core.events import (
    AppPayload,
    AssistantEvent,
    AssistantState,
    AutomationPayload,
    BrowserPayload,
    ErrorPayload,
    EventType,
    LogEntry,
    LogLevel,
    MessagePayload,
    Notification,
    StateChangePayload,
    SystemDiagnostics,
    TokenPayload,
)
from assistant.ui.bridge import EventDispatcher
from assistant.ui.interface import UIInterface

logger = logging.getLogger(__name__)


class CombinedMeta(type(QObject), ABCMeta):
    """Metaclass resolver for QObject (Shiboken.type) and ABCMeta multiple inheritance."""
    pass


# ════════════════════════════════════════════════════════════════════════════
# PySideDispatcher — thread bridge only, zero widget knowledge
# ════════════════════════════════════════════════════════════════════════════


class PySideDispatcher(QObject, EventDispatcher, metaclass=CombinedMeta):
    """Moves AssistantEvents from background threads onto the Qt GUI thread.

    Responsibility: thread-safe delivery only.
    It queues events (any thread) and drains them (GUI thread via QTimer).
    It calls adapter.handle_event() for each drained event and nothing else.

    Thread contract:
        dispatch()  — safe to call from any thread; enqueues without blocking.
        _drain()    — called exclusively from the GUI thread by QTimer.timeout.
    """

    #: How often the GUI thread checks for pending events (milliseconds).
    DRAIN_INTERVAL_MS: int = 20

    def __init__(
        self,
        adapter: UIInterface,
        parent: QObject | None = None,
    ) -> None:
        # QObject must be initialised explicitly when using multiple inheritance
        # to satisfy PySide6's metaclass; super() is not safe here.
        QObject.__init__(self, parent)
        self._adapter = adapter
        self._queue: queue.Queue[AssistantEvent] = queue.Queue()
        self._timer = QTimer(self)
        self._timer.setInterval(self.DRAIN_INTERVAL_MS)
        self._timer.timeout.connect(self._drain)
        self._active = False

    # ── EventDispatcher protocol ──────────────────────────────────────────────

    def dispatch(self, event: AssistantEvent) -> None:
        """Accept *event* from any thread. Returns immediately (non-blocking).

        The event is placed in a thread-safe queue; the GUI-thread QTimer
        will drain and deliver it within at most DRAIN_INTERVAL_MS.
        """
        self._queue.put(event)

    def start(self) -> None:
        """Start the drain timer and notify the adapter."""
        self._active = True
        self._timer.start()
        self._adapter.start()
        logger.info(
            "PySideDispatcher started (drain interval = %dms)",
            self.DRAIN_INTERVAL_MS,
        )

    def stop(self) -> None:
        """Stop the drain timer, flush remaining events, notify the adapter."""
        self._active = False
        self._timer.stop()
        self._drain()          # flush any events buffered before stop was called
        self._adapter.stop()
        logger.info("PySideDispatcher stopped")

    @property
    def is_running(self) -> bool:
        """True while the drain timer is active."""
        return self._active and self._timer.isActive()

    @property
    def adapter_name(self) -> str:
        return f"PySideDispatcher → {type(self._adapter).__name__}"

    # ── Internal drain — GUI thread only ─────────────────────────────────────

    def _drain(self) -> None:
        """Drain all queued events and deliver them to the adapter.

        Called exclusively from the Qt GUI thread (by QTimer.timeout or
        synchronously by stop()).  Each handle_event() call is wrapped in
        its own try/except so one bad handler never blocks delivery of
        subsequent events.
        """
        while True:
            try:
                event = self._queue.get_nowait()
            except queue.Empty:
                break
            try:
                self._adapter.handle_event(event)
            except Exception:
                logger.exception(
                    "PySideDispatcher: handle_event raised for event type %r",
                    event.type,
                )


# ════════════════════════════════════════════════════════════════════════════
# PySideAdapter — widget translation only, zero threading knowledge
# ════════════════════════════════════════════════════════════════════════════


class PySideAdapter(UIInterface):
    """Translates AssistantEvents into JarvisWindow widget API calls.

    Responsibilities:
      • Implement UIInterface.handle_event() using a dispatch table.
      • Call only public widget methods — never access private attributes.
      • Recover gracefully if the window is not yet connected or a widget
        does not yet expose the expected method.

    The window is injected after creation (connect_window) because the
    Qt window is instantiated after this adapter during startup.

    Dispatch table
    ──────────────
    _dispatch maps every EventType to a private handler method.  Unknown
    event types are silently ignored, ensuring new EventTypes never crash
    the running UI before a handler is written.

    Widget access
    ─────────────
    _chat, _history, _viz, _monitor are defensive properties that return
    None when the window or dashboard is not yet available.  Every handler
    checks for None before calling widget methods.
    """

    def __init__(self) -> None:
        self._window: Any = None
        self._dispatch: dict[EventType, Callable[[AssistantEvent], None]] = {}
        self._build_dispatch_table()

    # ── Window injection ──────────────────────────────────────────────────────

    def connect_window(self, window: Any) -> None:
        """Inject the JarvisWindow after Qt is initialised.

        Args:
            window: The live JarvisWindow instance.  Typed as ``Any`` to
                    avoid importing PySide6 UI modules here (they are in
                    jarvis-ui/ and have their own import graph).
        """
        self._window = window
        logger.info(
            "PySideAdapter: window connected (%s)", type(window).__name__
        )

    # ── UIInterface ───────────────────────────────────────────────────────────

    def handle_event(self, event: AssistantEvent) -> None:
        """Dispatch *event* to the registered handler, if any.

        Called from the GUI thread by PySideDispatcher._drain().
        Unknown event types are silently ignored for forward compatibility.
        Each handler wraps its own widget calls; exceptions here are the
        last line of defence — handlers should not raise.
        """
        handler = self._dispatch.get(event.type)
        if handler is None:
            return                      # forward-compatible: new types ignored
        try:
            handler(event)
        except Exception:
            logger.exception(
                "PySideAdapter: handler for %r raised — widget state may be "
                "inconsistent (source=%r, correlation=%s)",
                event.type,
                event.source,
                event.correlation_id,
            )

    def start(self) -> None:
        logger.debug("PySideAdapter ready")

    def stop(self) -> None:
        logger.debug("PySideAdapter stopped")

    @property
    def adapter_name(self) -> str:
        return "PySideAdapter (PySide6 Desktop)"

    # ── Dispatch table ────────────────────────────────────────────────────────

    def _build_dispatch_table(self) -> None:
        """Register all EventType → handler pairs in one place.

        Adding support for a new EventType is a two-step process:
          1. Add a handler method below (_on_<event>).
          2. Add one line here mapping the EventType to that method.
        No other code needs to change.
        """
        self._dispatch = {
            # ── State ─────────────────────────────────────────────────────────
            EventType.STATE_CHANGED:       self._on_state_changed,
            EventType.SLEEP_ENTERED:       self._on_sleep_entered,
            EventType.SLEEP_EXITED:        self._on_sleep_exited,
            # ── Wake ──────────────────────────────────────────────────────────
            EventType.WAKE_DETECTED:       self._on_wake_detected,
            EventType.WAKE_LOST:           self._on_wake_lost,
            # ── Recording ─────────────────────────────────────────────────────
            EventType.RECORDING_START:     self._on_recording_start,
            EventType.RECORDING_END:       self._on_recording_end,
            EventType.VOICE_INTERRUPTED:   self._on_voice_interrupted,
            # ── STT ───────────────────────────────────────────────────────────
            EventType.STT_START:           self._on_stt_start,
            EventType.STT_END:             self._on_stt_end,
            # ── LLM ───────────────────────────────────────────────────────────
            EventType.LLM_START:           self._on_llm_start,
            EventType.LLM_TOKEN:           self._on_llm_token,
            EventType.LLM_END:             self._on_llm_end,
            # ── Planner ───────────────────────────────────────────────────────
            EventType.PLANNER_START:       self._on_planner_start,
            EventType.PLANNER_END:         self._on_planner_end,
            EventType.COMMAND_PARSED:      self._on_command_parsed,
            # ── TTS ───────────────────────────────────────────────────────────
            EventType.TTS_START:           self._on_tts_start,
            EventType.TTS_END:             self._on_tts_end,
            # ── Messages ──────────────────────────────────────────────────────
            EventType.USER_MESSAGE:        self._on_user_message,
            EventType.ASSISTANT_MESSAGE:   self._on_assistant_message,
            # ── Automation ────────────────────────────────────────────────────
            EventType.AUTOMATION_START:    self._on_automation_start,
            EventType.AUTOMATION_END:      self._on_automation_end,
            EventType.APP_OPENED:          self._on_app_opened,
            # ── Browser ───────────────────────────────────────────────────────
            EventType.BROWSER_OPENED:      self._on_browser_opened,
            EventType.BROWSER_NAVIGATED:   self._on_browser_navigated,
            EventType.BROWSER_TAB_CHANGED: self._on_browser_tab_changed,
            # ── Memory ────────────────────────────────────────────────────────
            EventType.MEMORY_UPDATED:      self._on_memory_updated,
            # ── Diagnostics ───────────────────────────────────────────────────
            EventType.SYSTEM_DIAG:         self._on_system_diag,
            # ── Logging / errors / notifications ──────────────────────────────
            EventType.LOG:                 self._on_log,
            EventType.ERROR:               self._on_error,
            EventType.NOTIFICATION:        self._on_notification,
        }

    # ── Widget accessor properties ────────────────────────────────────────────
    # Each returns None when the window or dashboard is not yet available.
    # Handlers check for None so startup ordering does not cause crashes.

    @property
    def _chat(self) -> Any:
        """→ ChatPanel or None."""
        if self._window is None:
            return None
        return getattr(getattr(self._window, "dashboard", None), "chat", None)

    @property
    def _history(self) -> Any:
        """→ VoiceHistoryPanel or None."""
        if self._window is None:
            return None
        return getattr(getattr(self._window, "dashboard", None), "history", None)

    @property
    def _viz(self) -> Any:
        """→ VoiceVisualizer or None."""
        if self._window is None:
            return None
        return getattr(getattr(self._window, "dashboard", None), "viz", None)

    @property
    def _monitor(self) -> Any:
        """→ SystemMonitor widget or None."""
        if self._window is None:
            return None
        return getattr(getattr(self._window, "dashboard", None), "monitor", None)

    # ── Shared helpers ────────────────────────────────────────────────────────

    def _add_log(self, message: str, status: str = "ok") -> None:
        """Append one entry to VoiceHistoryPanel (no-op if not available)."""
        h = self._history
        if h is not None and hasattr(h, "add_entry"):
            ts = datetime.datetime.now().strftime("%H:%M:%S")
            h.add_entry(message, ts, status)

    def _set_orb(self, state: AssistantState) -> None:
        """Update VoiceVisualizer orb mode with a typed AssistantState."""
        v = self._viz
        if v is not None and hasattr(v, "set_state"):
            v.set_state(state)

    def _set_state(self, state: AssistantState) -> None:
        """Update JarvisWindow top-level state with a typed AssistantState."""
        if self._window is not None and hasattr(self._window, "set_state"):
            self._window.set_state(state)

    def _transition(self, state: AssistantState, log_msg: str = "") -> None:
        """Apply a state transition: window + orb + optional log entry.

        Passes the AssistantState enum directly — no .value string conversion.
        The window and orb are responsible for their own display mapping.
        """
        self._set_state(state)
        self._set_orb(state)
        if log_msg:
            self._add_log(log_msg)

    # ── State handlers ────────────────────────────────────────────────────────

    def _on_state_changed(self, event: AssistantEvent) -> None:
        p = event.payload
        if not isinstance(p, StateChangePayload):
            return
        self._transition(p.new_state, f"State -> {p.new_state.value}")

    def _on_sleep_entered(self, event: AssistantEvent) -> None:
        self._transition(AssistantState.SLEEPING, "Sleeping — waiting for wake word")

    def _on_sleep_exited(self, event: AssistantEvent) -> None:
        self._transition(AssistantState.IDLE, "Awake")

    # ── Wake handlers ─────────────────────────────────────────────────────────

    def _on_wake_detected(self, event: AssistantEvent) -> None:
        self._transition(AssistantState.IDLE)
        self._add_log("Wake word detected", "ok")

    def _on_wake_lost(self, event: AssistantEvent) -> None:
        self._add_log("Wake listener restarting…", "warn")

    # ── Recording handlers ────────────────────────────────────────────────────

    def _on_recording_start(self, event: AssistantEvent) -> None:
        self._transition(AssistantState.LISTENING, "Listening…")

    def _on_recording_end(self, event: AssistantEvent) -> None:
        self._add_log("Recording complete")

    def _on_voice_interrupted(self, event: AssistantEvent) -> None:
        self._add_log("Voice interrupted", "warn")

    # ── STT handlers ─────────────────────────────────────────────────────────

    def _on_stt_start(self, event: AssistantEvent) -> None:
        self._transition(AssistantState.THINKING, "Transcribing…")

    def _on_stt_end(self, event: AssistantEvent) -> None:
        self._add_log("Transcription complete")

    # ── LLM handlers ─────────────────────────────────────────────────────────

    def _on_llm_start(self, event: AssistantEvent) -> None:
        self._transition(AssistantState.THINKING, "Thinking…")
        c = self._chat
        if c is not None and hasattr(c, "begin_stream"):
            c.begin_stream()

    def _on_llm_token(self, event: AssistantEvent) -> None:
        # Phase 2: real token streaming via LLM_TOKEN events.
        # Currently the full reply arrives via ASSISTANT_MESSAGE.
        p = event.payload
        if isinstance(p, TokenPayload):
            c = self._chat
            if c is not None and hasattr(c, "append_token"):
                c.append_token(p.token)

    def _on_llm_end(self, event: AssistantEvent) -> None:
        self._add_log("Response ready")
        c = self._chat
        if c is not None and hasattr(c, "finish_stream"):
            c.finish_stream()

    # ── Planner handlers ──────────────────────────────────────────────────────

    def _on_planner_start(self, event: AssistantEvent) -> None:
        self._add_log("Planning…")

    def _on_planner_end(self, event: AssistantEvent) -> None:
        self._add_log("Plan complete")

    def _on_command_parsed(self, event: AssistantEvent) -> None:
        self._add_log("Command recognised", "ok")

    # ── TTS handlers ─────────────────────────────────────────────────────────

    def _on_tts_start(self, event: AssistantEvent) -> None:
        self._transition(AssistantState.SPEAKING, "Speaking…")

    def _on_tts_end(self, event: AssistantEvent) -> None:
        self._transition(AssistantState.IDLE, "Playback finished")

    # ── Message handlers ──────────────────────────────────────────────────────

    def _on_user_message(self, event: AssistantEvent) -> None:
        p = event.payload
        text = p.text if isinstance(p, MessagePayload) else str(p or "")
        if not text:
            return
        c = self._chat
        if c is not None and hasattr(c, "add_user_message"):
            c.add_user_message(text)
        self._add_log(f"You: {text[:60]}{'…' if len(text) > 60 else ''}")

    def _on_assistant_message(self, event: AssistantEvent) -> None:
        p = event.payload
        text = p.text if isinstance(p, MessagePayload) else str(p or "")
        if not text:
            return
        c = self._chat
        if c is not None and hasattr(c, "add_assistant_message"):
            c.add_assistant_message(text)

    # ── Automation handlers ───────────────────────────────────────────────────

    def _on_automation_start(self, event: AssistantEvent) -> None:
        p = event.payload
        desc = p.description if isinstance(p, AutomationPayload) else "Automation"
        self._transition(AssistantState.EXECUTING, f"Executing: {desc}")

    def _on_automation_end(self, event: AssistantEvent) -> None:
        p = event.payload
        ok = not isinstance(p, AutomationPayload) or p.success
        self._transition(AssistantState.IDLE)
        self._add_log("Command complete", "ok" if ok else "err")

    def _on_app_opened(self, event: AssistantEvent) -> None:
        p = event.payload
        name = p.app_name if isinstance(p, AppPayload) else str(p or "")
        self._add_log(f"Opened: {name}", "ok")

    # ── Browser handlers ──────────────────────────────────────────────────────

    def _on_browser_opened(self, event: AssistantEvent) -> None:
        p = event.payload
        url = p.url if isinstance(p, BrowserPayload) else ""
        self._add_log(f"Browser → {url or 'opened'}", "ok")

    def _on_browser_navigated(self, event: AssistantEvent) -> None:
        p = event.payload
        url = p.url if isinstance(p, BrowserPayload) else ""
        self._add_log(f"Navigated → {url}")

    def _on_browser_tab_changed(self, event: AssistantEvent) -> None:
        p = event.payload
        title = p.tab_title if isinstance(p, BrowserPayload) else ""
        self._add_log(f"Tab: {title}")

    # ── Memory handler ────────────────────────────────────────────────────────

    def _on_memory_updated(self, event: AssistantEvent) -> None:
        self._add_log("Memory updated")

    # ── Diagnostics handler ───────────────────────────────────────────────────

    def _on_system_diag(self, event: AssistantEvent) -> None:
        p = event.payload
        if not isinstance(p, SystemDiagnostics):
            return
        m = self._monitor
        if m is not None and hasattr(m, "update_real"):
            m.update_real(
                cpu=p.cpu_percent,
                ram=p.ram_percent,
                gpu=p.gpu_percent,
                disk=p.disk_percent,
            )

    # ── Log / error / notification handlers ──────────────────────────────────

    def _on_log(self, event: AssistantEvent) -> None:
        p = event.payload
        if isinstance(p, LogEntry):
            status = (
                "err"  if p.level == LogLevel.ERROR   else
                "warn" if p.level == LogLevel.WARNING else
                "ok"
            )
            self._add_log(p.message, status)
        else:
            self._add_log(str(p or ""))

    def _on_error(self, event: AssistantEvent) -> None:
        p = event.payload
        msg = p.message if isinstance(p, ErrorPayload) else str(p or "Error")
        self._transition(AssistantState.ERROR, f"Error: {msg}")

    def _on_notification(self, event: AssistantEvent) -> None:
        p = event.payload
        if not isinstance(p, Notification):
            return
        self._add_log(f"{p.title}: {p.message}")
        # show_notification() will be added to JarvisWindow in a later step.
        if self._window is not None and hasattr(self._window, "show_notification"):
            self._window.show_notification(p)
