"""Logging helpers."""

from __future__ import annotations

import logging
import sys
from logging.handlers import RotatingFileHandler

from rich.logging import RichHandler

from assistant.config import Settings


def configure_logging(settings: Settings) -> None:
    """Configure console and rotating file logging."""

    settings.log_file.parent.mkdir(parents=True, exist_ok=True)
    level = getattr(logging, settings.log_level, logging.INFO)

    root = logging.getLogger()
    root.setLevel(level)
    root.handlers.clear()

    rich_handler = RichHandler(rich_tracebacks=True, markup=True, show_path=False)
    rich_handler.setLevel(level)
    rich_handler.setFormatter(logging.Formatter("%(message)s"))

    file_handler = RotatingFileHandler(
        settings.log_file,
        maxBytes=1_000_000,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setLevel(level)
    file_handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s [%(name)s] %(message)s")
    )

    root.addHandler(rich_handler)
    root.addHandler(file_handler)
    sys.excepthook = _make_exception_hook(root)


def _make_exception_hook(logger: logging.Logger):
    def handle_exception(exc_type, exc_value, exc_traceback) -> None:
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        logger.critical("Unhandled exception", exc_info=(exc_type, exc_value, exc_traceback))

    return handle_exception


def get_logger(name: str) -> logging.Logger:
    """Return a module logger."""

    return logging.getLogger(name)
