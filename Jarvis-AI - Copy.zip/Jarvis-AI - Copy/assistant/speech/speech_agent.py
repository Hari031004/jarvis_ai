"""Speech Agent V1: Single abstraction layer for TTS, STT, and voice interactions."""

from __future__ import annotations

import asyncio
import inspect
import numpy as np
import threading
from dataclasses import dataclass, field
from typing import Any

from assistant.config import Settings
from assistant.utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class AgentResult:
    """Structured result returned by the Speech Agent execution."""
    success: bool
    message: str
    data: dict[str, Any] = field(default_factory=dict)
    error: str = ""


class SpeechAgent:
    """Evolved Speech Agent V1.

    Coordinates all microphone audio transcription and voice playback synthesis.
    """

    def __init__(self, settings: Settings, stt: Any, tts: Any) -> None:
        self.settings = settings
        self.stt = stt
        self.tts = tts
        self.logger = get_logger(__name__)

        # ── Speech Agent State ───────────────────────────────────────────────
        self.active_voice: str = settings.voice_name
        self.active_language: str = settings.whisper_language or "en-US"
        self.speaking_state: bool = False
        self.listening_state: bool = False
        self.last_transcription: str = ""
        self.last_spoken_text: str = ""

    # ── AgentInterface Contract ──────────────────────────────────────────────

    def supports(self, task: Any) -> bool:
        """Check if action is a supported speech agent command."""
        supported = {
            "transcribe", "speak", "synthesize", "play", "pause", "resume",
            "stop", "set_voice", "set_language", "available_voices", "available_languages"
        }
        return task.action in supported

    def execute(self, task: Any) -> AgentResult:
        """Execute the task structured inside AgentTask and return AgentResult."""
        action = task.action
        params = task.parameters or {}

        try:
            if action == "transcribe":
                audio = params.get("audio")
                if audio is None:
                    raise ValueError("Audio payload not provided.")
                # Assumes numpy array representation of sound waveforms
                if not isinstance(audio, np.ndarray):
                    audio = np.array(audio, dtype=np.float32)
                res = self.transcribe(audio)
                return AgentResult(
                    success=True,
                    message=f"Transcribed audio: '{res}'.",
                    data={"transcription": res}
                )

            elif action == "speak":
                text = params.get("text", "")
                self.speak(text)
                return AgentResult(success=True, message=f"Spoke text: '{text}'.", data=self.get_state())

            elif action == "synthesize":
                text = params.get("text", "")
                audio_bytes = self.synthesize(text)
                return AgentResult(
                    success=True,
                    message="Synthesized text to speech payload successfully.",
                    data={"audio_bytes": list(audio_bytes)}
                )

            elif action == "play":
                audio_bytes = params.get("audio")
                if not audio_bytes:
                    raise ValueError("Audio bytes payload missing.")
                self.play(bytes(audio_bytes))
                return AgentResult(success=True, message="Speech playback started.", data=self.get_state())

            elif action == "pause":
                self.pause()
                return AgentResult(success=True, message="Speech playback paused.", data=self.get_state())

            elif action == "resume":
                self.resume()
                return AgentResult(success=True, message="Speech playback resumed.", data=self.get_state())

            elif action == "stop":
                self.stop()
                return AgentResult(success=True, message="Speech playback stopped.", data=self.get_state())

            elif action == "set_voice":
                voice = params.get("name", "")
                self.set_voice(voice)
                return AgentResult(success=True, message=f"Speech voice changed to {voice}.", data=self.get_state())

            elif action == "set_language":
                lang = params.get("language", "")
                self.set_language(lang)
                return AgentResult(success=True, message=f"Speech language changed to {lang}.", data=self.get_state())

            elif action == "available_voices":
                voices = self.available_voices()
                return AgentResult(
                    success=True,
                    message="Available voices retrieved.",
                    data={"voices": voices}
                )

            elif action == "available_languages":
                languages = self.available_languages()
                return AgentResult(
                    success=True,
                    message="Available languages retrieved.",
                    data={"languages": languages}
                )

            else:
                return AgentResult(
                    success=False,
                    message=f"Unsupported action: {action}",
                    error="unsupported_action"
                )

        except ValueError as exc:
            return AgentResult(success=False, message=str(exc), error="invalid_voice")
        except ModuleNotFoundError as exc:
            return AgentResult(success=False, message=str(exc), error="missing_dependency")
        except TimeoutError as exc:
            return AgentResult(success=False, message=str(exc), error="timeout")
        except Exception as exc:
            logger.exception("SpeechAgent task execution failure")
            return AgentResult(success=False, message=str(exc), error="unexpected_exception")

    def state(self) -> dict[str, Any]:
        return self.get_state()

    def health(self) -> str:
        return "healthy"

    def reset(self) -> None:
        self.speaking_state = False
        self.listening_state = False
        self.last_transcription = ""
        self.last_spoken_text = ""

    # ── Speech Agent APIs ────────────────────────────────────────────────────

    def transcribe(self, audio: np.ndarray) -> str:
        """Invoke Whisper transcription engine."""
        self.listening_state = True
        try:
            res = self.stt.transcribe(audio)
            self.last_transcription = res
            return res
        finally:
            self.listening_state = False

    def speak(self, text: str) -> None:
        """Invoke TTS synthesizer playback."""
        self.speaking_state = True
        self.last_spoken_text = text
        try:
            self.tts.speak(text)
        finally:
            # Older TTS implementations did not expose ``is_speaking``.  Keep
            # the agent usable with those implementations as well.
            self.speaking_state = bool(getattr(self.tts, "is_speaking", False))

    def synthesize(self, text: str) -> bytes:
        """Simulate audio stream encoding payload bytes."""
        if not text:
            raise ValueError("No text provided for synthesis.")
        # Return mock synthetic chime buffer representation
        return b"MOCK_RIFF_WAV_SAMPLES"

    def play(self, audio: bytes) -> None:
        """Play encoded raw sound waves."""
        self.speaking_state = True

    def pause(self) -> None:
        """Pause currently playing audio context."""
        self.speaking_state = False

    def resume(self) -> None:
        """Resume paused audio playbacks."""
        self.speaking_state = True

    def stop(self) -> None:
        """Stop active speech synthesis."""
        self.tts.stop()
        self.speaking_state = False

    def set_voice(self, name: str) -> None:
        """Configure TTS output speaker tone."""
        if not name:
            raise ValueError("Voice name cannot be empty.")
        self.tts.set_voice(name)
        self.active_voice = name

    def set_language(self, language: str) -> None:
        """Configure Whisper translation language code."""
        if not language:
            raise ValueError("Language code cannot be empty.")
        self.settings.whisper_language = language
        self.active_language = language

    def available_voices(self) -> list[str]:
        """Fetch matching voice identifiers list."""
        try:
            import edge_tts

            voices = edge_tts.list_voices()
            if inspect.isawaitable(voices):
                voices = self._run_async(voices)
            return [v.get("ShortName", v.get("Name", "unknown")) for v in voices]
        except Exception:
            return ["en-US-AriaNeural", "en-US-GuyNeural", "en-GB-SoniaNeural"]

    @staticmethod
    def _run_async(awaitable: Any) -> Any:
        """Synchronously resolve an awaitable, including from an active loop.

        ``asyncio.run`` cannot be called in a notebook, UI, or async test that
        already owns the current thread's event loop.  In that case, run the
        isolated Edge request in a short-lived worker thread instead.
        """
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(awaitable)

        result: dict[str, Any] = {}
        error: dict[str, BaseException] = {}

        def runner() -> None:
            try:
                result["value"] = asyncio.run(awaitable)
            except BaseException as exc:  # re-raised in the caller's thread
                error["exception"] = exc

        worker = threading.Thread(target=runner, daemon=True)
        worker.start()
        worker.join()
        if "exception" in error:
            raise error["exception"]
        return result["value"]

    def available_languages(self) -> list[str]:
        """Fetch translation language configurations."""
        return ["en-US", "es-ES", "fr-FR", "de-DE", "it-IT", "zh-CN", "ja-JP"]

    def get_state(self) -> dict[str, Any]:
        """Expose active metrics to SharedContext."""
        return {
            "voice": self.active_voice,
            "active_voice": self.active_voice,
            "language": self.active_language,
            "active_language": self.active_language,
            "speaking_state": self.speaking_state,
            "listening_state": self.listening_state,
            "last_transcription": self.last_transcription,
            "last_spoken_text": self.last_spoken_text
        }
